package com.example.terrariabosscreator;

public enum PreHardModeBosses {
    KING_SLIME("King slime"),
    EYE_OF_CTHULHU("Eye of cthulhu"),
    EATER_OF_WORLDS("Eater of worlds"),
    BRAIN_OF_CTHULHU("Brain of cthulhu"),
    QUEEN_BEE("Queen bee"),
    SKELETRON("Skeletron"),
    DEERCLOPS("Deerclops"),
    WALL_OF_FLESH("Wall of flesh");


    private String friendlyBoss;

    PreHardModeBosses(String friendlyBoss){
      this.friendlyBoss = friendlyBoss;
    }
    public void getFriendlyBoss(){
        this.friendlyBoss = friendlyBoss;

    }

    @Override
    public String toString() {
        return this.friendlyBoss;
    }
}
