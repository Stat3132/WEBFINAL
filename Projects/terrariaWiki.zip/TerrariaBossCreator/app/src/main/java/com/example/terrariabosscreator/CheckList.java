package com.example.terrariabosscreator;

public class CheckList {
    private String difficultyBeatenIn;
    private int rating;
    private Boss boss;
    private Boss[] bossRe;


    public CheckList(String difficultyBeatenIn, int rating) throws InvalidDifficultyException,InvalidRatingException{
        setDifficultyBeatenIn(difficultyBeatenIn);
        setRating(rating);

    }
    public String getDifficultyBeatenIn() {
        return difficultyBeatenIn;
    }

    private void setDifficultyBeatenIn(String difficultyBeatenIn) throws InvalidDifficultyException {
        if (difficultyBeatenIn != null && difficultyBeatenIn.length() == 6 && difficultyBeatenIn.equalsIgnoreCase("Normal") || difficultyBeatenIn.equalsIgnoreCase("Expert") || difficultyBeatenIn.equalsIgnoreCase("Master") ) {
            this.difficultyBeatenIn = difficultyBeatenIn;
        } else {
            throw new InvalidDifficultyException("Wrong input \n\n" + "Can only be Normal, Expert, or Master");
        }
    }

    public int getRating() {
        return rating;
    }

    private void setRating(int rating) throws InvalidRatingException{
        if (rating >= 1 && rating <= 10) {
            this.rating = rating;
        } else {
            throw new InvalidRatingException("Number should only be between 1 to 10");
        }
    }
    @Override
    public String toString() {
        StringBuilder stringCheckList = new StringBuilder();
        stringCheckList.append("Beaten in: ").append(difficultyBeatenIn).append("\n");
        stringCheckList.append("Rating: ").append(rating).append("/10");
        return stringCheckList.toString();
    }
}
