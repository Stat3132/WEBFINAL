package com.example.terrariabosscreator;

public class BossLibrary {
    final int BOSSMAX = 18;
    Boss[] makingBosses = new Boss[BOSSMAX];
    Boss[] makingExpertBoss = new Boss[BOSSMAX];
    Boss[] makingMasterBoss = new Boss[BOSSMAX];
    Boss[] makingAlteringStateBoss = new Boss[BOSSMAX];
    Boss[] makingExpertAlteringStateBoss = new Boss[BOSSMAX];
    Boss[] makingMasterAlteringStateBoss = new Boss[BOSSMAX];

    private int bossIndexNumber = 0;
    private int bossIndexExpert = 0;
    private int bossIndexMaster = 0;
    private int stationaryIndexNumber = 0;
    private int stationaryExpert = 0;
    private int stationaryMaster = 0;

    /**
     * This is where all the bosses are created and all of there information is inputted into an array
     * The bossIndexNumber is increased here because this is where all the bosses are created.
     */
    public Boss creatingBosses() {

        /**
         * All bosses under here are Pre hardmode bosses and display all constructor information for each of the bosses. That is then put in an array that holds Bosses.
         */


            Boss boss1 = new Boss(
                    PreHardModeBosses.KING_SLIME.toString(),
                    2_000,
                    false,
                    "Normal",
                    false,
                    "slimy saddle, Ninja set(Ninja hood, Ninja shirt, Ninja pants) , Slime hook, Slime gun, Lesser healing potion, King slime mask, King slime trophy",
                    "No lootbag" + "" + "(Currently on normal)",
                    "Slime crown or killing pinky in the slime rain event");
            makingBosses[0] = boss1;
            bossIndexNumber++;
            stationaryIndexNumber++;

        //SECOND FORM OF KING SLIME, SS = Second form
        Boss kingSlimeSS = new Boss("King slime", true, 2_000, "Normal");
        makingAlteringStateBoss[0] = kingSlimeSS;

            Boss boss2 = new Boss(
                    PreHardModeBosses.EYE_OF_CTHULHU.toString(),
                    2_800,
                    false,
                    "Normal",
                    false,
                    "Demonite ore, Unholy arrow, Corrupt seeds, Binoculars, Lesser healing potion, Badgers hat, Eye of cthulhu mask, Eye of cthulhu trophy, foul juice",
                    "No lootbag" + "" + "(Currently on normal",
                    "Use a Suspicious looking eye" + " " + "or" + " There is a 1/3 chance of the eye spawning automatically at night");

            makingBosses[1] = boss2;
            bossIndexNumber++;
            stationaryIndexNumber++;
            // SECOND FORM OF EYE OF CTHULHU
            Boss eyeOfCthulhuSS = new Boss("Eye of cthulhu", true, 1400, "Normal");
            makingAlteringStateBoss[1] = eyeOfCthulhuSS;

            Boss boss3 = new Boss(
                    PreHardModeBosses.EATER_OF_WORLDS.toString(),
                    10_050,
                    false,
                    "Normal",
                    false,
                    "Shadow scale, Demonite ore, Eaters bone, Lesser healing potion, Eater of worlds mask, Eater of worlds trophy, Dread fang",
                    "No lootbag" + ("Currently on normal"),
                    "Use worm food or Destroy 3 shadow orbs that spawn in the corruption");
            makingBosses[2] = boss3;
            bossIndexNumber++;
            stationaryIndexNumber++;
            // SECOND FORM OF EATER OF WORLDS
            Boss eaterOfWorldsSS = new Boss("Eater of worlds", true, 10_050, "Normal");
            makingAlteringStateBoss[2] = eaterOfWorldsSS;


            Boss boss4 = new Boss(
                    PreHardModeBosses.BRAIN_OF_CTHULHU.toString(),
                    3_250,
                    false,
                    "Normal",
                    false,
                    "Crimtane ore, Bone rattle, Lesser healing potion, Brain of cthulhu mask, Brain of cthulhu trophy, Dread fangs",
                    "No lootbag" + ("Currently on normal"),
                    "Use a bloody spine or Destroy 3 crimson hearts");
            makingBosses[3] = boss4;
            bossIndexNumber++;
            stationaryIndexNumber++;

            Boss brainOfCthulhuSS = new Boss("Brain of cthulhu", true, 1_250, "Normal");
            makingAlteringStateBoss[3] = brainOfCthulhuSS;

            Boss boss5 = new Boss(
                    PreHardModeBosses.QUEEN_BEE.toString(),
                    3_400,
                    false,
                    "Normal",
                    false,
                    "Bee gun, Bee keeper, The bee's knees, Hive wand, Bee hat, Bee shirt, Bee pants, Honey comb, Nectar, Honeyed googles, Beenade, Bee wax, Bottled honey, Queen bee mask, Queen bee trophu ",
                    "No lootbag" + ("Currently on normal"),
                    "Break the larva inside of a bee hive or by using abeemination anywhere in the jungle");
            makingBosses[4] = boss5;
            bossIndexNumber++;
            stationaryIndexNumber++;

            Boss queenBeeSS = new Boss("Queen bee", true, 3_400, "Normal");
            makingAlteringStateBoss[4] = queenBeeSS;

            Boss boss6 = new Boss(
                    PreHardModeBosses.SKELETRON.toString(),
                    4_400,
                    false,
                    "Normal",
                    false,
                    "Healing potions, Lesser healing potion, Skeletron mask, Skeletron hand, Book of skulls, Skeletron trophy, Chippys couch, Weird scales",
                    "No lootbag" + ("Currently on normal"),
                    "Talking to the clothier at night will summon Skeletron");
            makingBosses[5] = boss6;
            bossIndexNumber++;
            stationaryIndexNumber++;

            Boss skeletronSS = new Boss("Skeletron", true, 4_400, "Normal");
            makingAlteringStateBoss[5] = skeletronSS;

        Boss boss7 = new Boss(
                PreHardModeBosses.DEERCLOPS.toString(),
                7_000,
                false,
                "Normal",
                false,
                "healing potion, Eye bone, Eyebrella, Radio thing, Dizzy's rare gecko chester, Pew-matic horn, Weather pain, Houndlus shoootlus, Lucy the axe, Deerclops mask, Deerclops trophy",
                "No lootbag" + ("Currently on normal"),
                "You find Deerclops in the snow biome during a blizzard if one player has atleast 9 defense and 200 health or by summoning it with a deer thing in the snow biome");
        makingBosses[6] = boss7;
        bossIndexNumber++;
        stationaryIndexNumber++;

        Boss deerclopsSS = new Boss("Deerclops", true, 7_000, "Normal");
        makingAlteringStateBoss[6] = deerclopsSS;

        Boss boss8 = new Boss(
                PreHardModeBosses.WALL_OF_FLESH.toString(),
                8_000,
                false,
                "Normal",
                false,
                "Pwnhammer, Breaker blade, Clockwork assault rifle, Laser rifle, Firecracker, Warrior emblem, Ranger emblem, Sorcer emblem, Summoner emblem, Healing potion, Badgers hat, Wall of flesh mask, Wall of flesh trophy, Twisted slag",
                "No lootbag" + ("Currently on normal"),
                "Spawns only in the underworld. To summon The Wall Of Flesh you must destroy a guide voodoo doll by dropping it in lava located in the underworld");
        makingBosses[7] = boss8;
        bossIndexNumber++;
        stationaryIndexNumber++;

        Boss wallOfFleshss = new Boss("Wall of flesh", true, 8_000, "Normal");
        makingAlteringStateBoss[7] = wallOfFleshss;
        /**
         * All bosses Under are all POST hardmode bosses or just hardmode bosses. The boss constructor information is kept here and is incremented and put in a boss array,
         * holding the bosses information in a seperate array.
         */

        Boss boss9 = new Boss(
                HardModeBosses.QUEEN_SLIME.toString(),
                18_000,
                false,
                "Normal",
                false,
                "Sparkle slime balloons, Crystal assassin hood, Crystal assassin shirt, Crystal assassin pants, Blade staff, Gelatinous pillion, Hook of dissonance, Greater healing potion, Queen slime mask, Queen slime trophy",
                "No lootbag" + ("Currently on normal"),
                "Queen slime is spawned ONLY in the hallow with a gelatin crystal");
        makingBosses[8] = boss9;
        bossIndexNumber++;
        stationaryIndexNumber++;

        Boss queenSlimeSS = new Boss("Queen slime", true, 9_000, "Normal");
        makingAlteringStateBoss[8] = queenSlimeSS;

        Boss boss10 = new Boss(
                HardModeBosses.THE_TWINS.toString(),
                43_000,
                false,
                "Normal",
                false,
                "Souls of sight, Hallowed bars, Horned god boots, Greater healing potion, Twin mask, Retinazar trophy, Spazmatism trophy",
                "No lootbag" + ("Currently on normal"),
                "The twins can be spawned using a mechanical eye or at night they have a 1/10 chance to spawn naturally");
        makingBosses[9] = boss10;
        bossIndexNumber++;
        stationaryIndexNumber++;

        Boss theTwinsSS = new Boss("The twins (Retinazar and Spazmatism)", true, 21_500, "Normal");
        makingAlteringStateBoss[9] = theTwinsSS;

        Boss boss11 = new Boss(
                HardModeBosses.THE_DESTORYER.toString(),
                80_000,
                false,
                "Normal",
                false,
                "Soul of might, Hallowed bars, Horned god robe, Greater healing potion, Destroyer mask, Destroyer trophy",
                "No lootbag" + ("Currently on normal"),
                "The destroyer can be summoned with a mechanical worm OR it has a 1/10 chance of spawning in dusk");
        makingBosses[10] = boss11;
        bossIndexNumber++;
        stationaryIndexNumber++;

        Boss theDestroyerSS = new Boss("The destroyer", true, 80_000, "Normal");
        makingAlteringStateBoss[10] = theDestroyerSS;

        Boss boss12 = new Boss(
                HardModeBosses.SKELETRON_PRIME.toString(),
                28_000,
                false,
                "Normal",
                false,
                "Soul of fright, Hallowed bars, Horned god mask, Greater healing potion, Skeletron prime mask, Skeletron prime trophy",
                "No lootbag" + ("Currently on normal"),
                "Skeletron prime can be summoned using the mechanical skull OR it has a 1/10 chance of spawning in dusk");
        makingBosses[11] = boss12;
        bossIndexNumber++;
        stationaryIndexNumber++;

        Boss skeletronPrimeSS = new Boss("Skeletron prime", true, 28_000, "Normal");
        makingAlteringStateBoss[11] = skeletronPrimeSS;

        Boss boss13 = new Boss(
                HardModeBosses.PLANTERA.toString(),
                30_000,
                false,
                "Normal",
                false,
                "Temple key, Grenade launcher, Rocket, Venus magnus, Nettle burst, Leaf blower, Flower pow, Wasp gun, Seedler, Pygmy staff, Thorn hook, The axe, Seedling, Zapinator, Greater healing potion, Plantera mask, Plantera trophy ",
                "No lootbag" + ("Currently on normal"),
                "After all three mechanical bosses are fought you can find plantera bulbs in the jungle that will spawn plantera.");
        makingBosses[12] = boss13;
        bossIndexNumber++;
        stationaryIndexNumber++;

        Boss planteraSS = new Boss("Plantera", true, 15_000, "Normal");
        makingAlteringStateBoss[12] = planteraSS;

        Boss boss14 = new Boss(
                HardModeBosses.GOLEM.toString(),
                60_000,
                false,
                "Normal",
                false,
                "Picksaw, Beetle husk, Stynger, Stynger bolts, Possessed hatchet, Sun stone, Eye of golem, Heat ray, Staff of earth, Golem fist, Greater healing potion, Golem mask, Golem trophy",
                "No lootbag" + ("Currently on normal"),
                "The temple key that is dropped by plantera is used to open the jungle temple and that using a Lizahrd power cell at the Lizahrd altar");
        makingBosses[13] = boss14;
        bossIndexNumber++;
        stationaryIndexNumber++;

        Boss golemSS = new Boss("Golem", true, 30_000, "Normal");
        makingAlteringStateBoss[13] = golemSS;

        Boss boss15 = new Boss(
                HardModeBosses.DUKE_FISHERON.toString(),
                60_000,
                false,
                "Normal",
                false,
                "Bubble gun, Flairon, Razerblade typhoon, Tempest staff, Tsunami, Fishron wings, Greater healing potion, Lesser healing potion, Duke fishron mask, Duke fishron  trophy",
                "No lootbag" + ("Currently on normal"),
                "Duke fishron is summoned by fishing in the ocean using truffle worm as bait. That is a rare critter found underground in the mushroom biome that is caught with a bug net");
        makingBosses[14] = boss15;
        bossIndexNumber++;
        stationaryIndexNumber++;

        Boss dukeFishronSS = new Boss("Duke fishron: ", true, 30_000, "Normal");
        makingAlteringStateBoss[14] = dukeFishronSS;

        Boss boss16 = new Boss(
                HardModeBosses.EMPRESS_OF_LIGHT.toString(),
                70_000,
                false,
                "Normal",
                false,
                "Nightglow, Starlight, Kaleidoscope, Eventide, Empress wings, Prismatic dye, Stellar tune, Rainbow cursor, Terraprisma, Greater healing potion, Empress of light mask, Empress of light trophy",
                "No lootbag" + ("Currently on normal"),
                "Empress of light is summoned by killing a prismatic lacewing, a rare critter that spawns in the surface of the hollow AFTER plantera has been defeated.");
        makingBosses[15] = boss16;
        bossIndexNumber++;
        stationaryIndexNumber++;

        Boss empressOfLightSS = new Boss("Empress of light", true, 35_000, "Normal");
        makingAlteringStateBoss[15] = empressOfLightSS;
        Boss boss17 = new Boss(
                HardModeBosses.LUNATIC_CULTIST.toString(),
                32_000,
                false,
                "Normal",
                false,
                "Ancient manipulator, Lunatic cultist mask, Lunatic cultist trophy, Greater healing potion",
                "No lootbag" + ("Currently on normal"),
                "Post Golem boss summoned by killing the cultist that spawns at the entrance of the dungeon after Golem is defeated");
        makingBosses[16] = boss17;
        bossIndexNumber++;
        stationaryIndexNumber++;

        Boss lunaticCultistSS = new Boss("Lunatic cultist: ", true, 32_000, "Normal");
        makingAlteringStateBoss[16] = lunaticCultistSS;

        Boss boss18 = new Boss(
                HardModeBosses.MOON_LORD.toString(),
                145_000,
                false,
                "Normal",
                false,
                "Portal gun, Meowmere, Terrarian, Star wrath, S.D.M.G, Last prism, Lunar flare, Rainbow crystal staff, Lunar portal staff, Celebration Mk2, Celebration, Meowmere minecraft, Super healing potion, Greater healing potion, Moon lord mask, Moon lord trophy",
                "No lootbag" + ("Currently on normal"),
                "After destroying all 4 celestial pillars moon lord spawns OR using celestial sigil. These have to be done AFTER Golem has been defeated.");
        makingBosses[17] = boss18;
        bossIndexNumber++;
        stationaryIndexNumber++;

        Boss moonLordSS = new Boss("Moon lord: ", true, 145_000, "Normal");
        makingAlteringStateBoss[17] = moonLordSS;


        // EXPERT BOSSES INFORMATION

        Boss boss1E = new Boss("King slime", 2_800, "Expert", true, "Royal gel, King slime mask, Slimy saddle, Ninja hood, Ninja shirt, Ninja pants, Slime gun, Slime hook, Solidifier, 1 gold coin");
        makingExpertBoss[0] = boss1E;
        bossIndexExpert++;
        stationaryExpert++;
        Boss kingSlimeExpertSS = new Boss("King slime", true, 2_800, "Expert");
        makingExpertAlteringStateBoss[0] = kingSlimeExpertSS;

        Boss boss2E = new Boss("Eye of cthulhu", 3_640, "Expert", true, "Shield of cthulhu, Eye of cthulhu mask, Binoculars, Demonite ore or Crimtane ore, Unholy arrows, Corrupt seeds or Crimson seeds");
        makingExpertBoss[1] = boss2E;
        bossIndexExpert++;
        stationaryExpert++;
        Boss eyeOfCthulhuExpertSS = new Boss("Eye of cthulhu", true, 2_366,"Expert");
        makingExpertAlteringStateBoss[1] = eyeOfCthulhuExpertSS;

        Boss boss3E = new Boss("Eater of worlds", 15_120, "Expert", true, "Worm scarf, Eater of worlds mask, Demonite ore, Shadow scale, Eater bones");
        makingExpertBoss[2] = boss3E;
        bossIndexExpert++;
        stationaryExpert++;
        Boss eaterOfWorldExpertsSS = new Boss("Eater of worlds", true, 15_120, "Expert");
        makingExpertAlteringStateBoss[2] = eaterOfWorldExpertsSS;

        Boss boss4E = new Boss("Brain of cthulhu", 5_525, "Expert", true, "Brain of confusion, Brain of cthulhu mask, Crimtane ore, Tissue sample, Bone rattle");
        makingExpertBoss[3] = boss4E;
        bossIndexExpert++;
        stationaryExpert++;
        Boss brainOfCthulhuExpertSS = new Boss("Brain of cthulhu", true, 2_125,"Expert");
        makingExpertAlteringStateBoss[3] = brainOfCthulhuExpertSS;

        Boss boss5E = new Boss("Queen bee", 4_760, "Expert", true, "Hive pack, Queen bee mask, Bee gun, Bee keeper, The bee's knees, Honey comb, Nectar, Honeyed goggles, Hive wand");
        makingExpertBoss[4] = boss5E;
        bossIndexExpert++;
        stationaryExpert++;
        Boss queenBeeExpertSS = new Boss("Queen bee", true, 4_760, "Expert");
        makingExpertAlteringStateBoss[4] = queenBeeExpertSS;

        Boss boss6E = new Boss("Skeletron", 8_800, "Expert", true, "Bone gloves, Skeletron mask, Book of skulls");
        makingExpertBoss[5] = boss6E;
        bossIndexExpert++;
        stationaryExpert++;
        Boss skeletronExpertSS = new Boss("Skeletron", true, 8_800, "Expert");
        makingExpertAlteringStateBoss[5] = skeletronExpertSS;

        Boss boss7E = new Boss("Deerclops", 11_900, "Expert", true, "Bone helm, Deerclops mask, Eye bone, Eyebrella, Radio thing, Dizzy's rare gecko chester, Pew-matic horn, Weather pain, Houndius shootuis, Lucy the axe");
        makingExpertBoss[6] = boss7E;
        bossIndexExpert++;
        stationaryExpert++;
        Boss deerclopsExpertSS = new Boss("Deer clops", true, 11_900, "Expert");
        makingExpertAlteringStateBoss[6] = deerclopsExpertSS;

        Boss boss8E = new Boss("Wall of flesh", 11_200, "Expert", true, "Demon heart, Wall of flesh mask, Pwnhammer, Warrior emblem, Ranger emblem, Sorcerer emblem, Summoners emblem, Breaker blade, Clockwork assault rifle, Laser rifle, Firecracker");
        makingExpertBoss[7] = boss8E;
        bossIndexExpert++;
        stationaryExpert++;
        Boss wallOfFleshExpertSS = new Boss("Wall of flesh", true, 11_200, "Expert");
        makingExpertAlteringStateBoss[7] = wallOfFleshExpertSS;

        Boss boss9E = new Boss("Queen slime", 28_800, "Expert", true, "Volatile getaltin, Sparkle slime balloon, Queen slime mask, Gelatinous pillion, Hook of dissonance, Blade staff, Crystal assassin hood, Crystal assassin shirt, Crystal assassin pants");
        makingExpertBoss[8] = boss9E;
        bossIndexExpert++;
        stationaryExpert++;
        Boss queenSlimeExpertSS = new Boss("Queen slime", true, 14_400, "Expert");
        makingExpertAlteringStateBoss[8] = queenSlimeExpertSS;

        Boss boss10E = new Boss("The twins (Retinazar and Spazmatism)", 64_500, "Expert", true, "Mechanical wheel piece, Twin mask, Soul of sight, Hallowed bar");
        makingExpertBoss[9] = boss10E;
        bossIndexExpert++;
        stationaryExpert++;
        Boss theTwinsExpertSS = new Boss("The twins (Retinazar and Spazmatism", true,  32_250, "Expert");
        makingExpertAlteringStateBoss[9] = theTwinsExpertSS;

        Boss boss11E = new Boss("The destroyer", 120_000, "Expert", true, "Mechanical wagon piece, Destroyer mask, Soul of might, Hallowed bar");
        makingExpertBoss[10] = boss11E;
        bossIndexExpert++;
        stationaryExpert++;
        Boss theDestroyerExpertSS = new Boss("The destroyer", true, 120_000, "Expert");
        makingExpertAlteringStateBoss[10] = theDestroyerExpertSS;

        Boss boss12E = new Boss("Skeletron prime", 42_000, "Expert", true, "Mechanical battery piece, Skeletron prime mask, Soul of fright, Hallowed bar");
        makingExpertBoss[11] = boss12E;
        bossIndexExpert++;
        stationaryExpert++;
        Boss skeletronPrimeExpertSS = new Boss("Skeletron prime", true, 42_000, "Expert");
        makingExpertAlteringStateBoss[11] = skeletronPrimeExpertSS;


        Boss boss13E = new Boss("Plantera", 42_000, "Expert", true, "Spore sac, Plantera mask, Temple key, Grenade launcher, Venus magnum, Nettle burst, Leaf blower, Flower pow, Wasp gun, Seedler, Seedling, The axe, Pygmy staff, Thorn hook");
        makingExpertBoss[12] = boss13E;
        bossIndexExpert++;
        stationaryExpert++;
        Boss planteraExpertSS = new Boss("Plantera", true, 21_000, "Expert");
        makingExpertAlteringStateBoss[12] = planteraExpertSS;

        Boss boss14E = new Boss("Golem", 90_000, "Expert", true, "Shiny stone, Golem mask, Picksaw, Stynger, Possessed hatchet, Sun stone, Eye of the golem, Picksaw, Heat ray, Staff of earth, Golem fist, Beetle husk");
        makingExpertBoss[13] = boss14E;
        bossIndexExpert++;
        stationaryExpert++;
        Boss golemExpertSS = new Boss("Golem", true, 45_000, "Expert");
        makingExpertAlteringStateBoss[13] = golemExpertSS;

        Boss boss15E = new Boss("Duke fishron", 78_000, "Expert", true, "Shrimpy truffle, Duke fishron mask, Bubble gun, Flairon, Razorblade typhoon, Tempest staff, Tsunami, Fishron wings");
        makingExpertBoss[14] = boss15E;
        bossIndexExpert++;
        stationaryExpert++;
        Boss dukeFishronExpertSS = new Boss("Duke fishron", true, 39_000, "Expert");
        makingExpertAlteringStateBoss[14] = dukeFishronExpertSS;

        Boss boss16E = new Boss("Empress of light", 98_000, "Expert", true, "Nightglow, Starlight, Kaleidoscope, Eventide, Soaring insignia, Empress of light mask, Empress wings, Stellar tune, Rainbow cursor, Prismatic dye");
        makingExpertBoss[15] = boss16E;
        bossIndexExpert++;
        stationaryExpert++;
        Boss empressOfLightExpertSS = new Boss("Empress of light", true, 98_000, "Expert");
        makingExpertAlteringStateBoss[15] = empressOfLightExpertSS;

        Boss boss17E = new Boss("Lunatic cultist", 49_000, "Expert", false, "No lootbag");
        makingExpertBoss[16] = boss17E;
        bossIndexExpert++;
        stationaryExpert++;
        Boss lunaticCultistExpertSS = new Boss("Lunatic cultist", true, 48_000, "Expert");
        makingExpertAlteringStateBoss[16] = lunaticCultistExpertSS;

        Boss boss18E = new Boss("Moon lord", 217_500, "Expert", true, "Gravity globe, Suspicious looking tentacle, Celestial starboard, Moon lord mask, Meowmere, Terrarian, Star wrath, S.D.M.G, Last prism, Lunar flare, Rainbow crystal staff, Lunar portal staff, Celebration mk2, Celebration, Portal gun, Luminite, Meowmere minecart");
        makingExpertBoss[17] = boss18E;
        bossIndexExpert++;
        stationaryExpert++;
        Boss moonLordExpertSS = new Boss("Moon lord", true, 217_500, "Expert");
        makingExpertAlteringStateBoss[17] = moonLordExpertSS;


        // MASTER MODE BOSS INFO


        Boss boss1M = new Boss("King slime", 3_570, "Master", true, "Royal delight, King slime relic, Royal gel, King slime mask, Slimy saddle, Ninja hood, Ninja shirt, Ninja pants, Slime gun, Slime hook, Solidifier, 1 gold coin");
        makingMasterBoss[0] = boss1M;
        bossIndexMaster++;
        stationaryMaster++;
        Boss kingSlimeMasterSS = new Boss("King slime", true, 3_570, "Master");
        makingMasterAlteringStateBoss[0] = kingSlimeMasterSS;

        Boss boss2M = new Boss("Eye of cthulhu", 4_641, "Master", true, "Eye of cthulhu relic, 0x33's aviators, Suspicous grinning eye, Shield of cthulhu, Eye of cthulhu mask, Binoculars, Demonite ore or Crimtane ore, Unholy arrows, Corrupt seeds or Crimson seeds");
        makingMasterBoss[1] = boss2M;
        bossIndexMaster++;
        stationaryMaster++;
        Boss eyeOfCthulhuMasterSS = new Boss("Eye of cthulhu", true, 3_016, "Master");
        makingMasterAlteringStateBoss[1] = eyeOfCthulhuMasterSS;

        Boss boss3M = new Boss("Eater of worlds", 19_224, "Master", true, "Writhing remains, Eater of worlds relic, Worm scarf, Eater of worlds mask, Demonite ore, Shadow scale, Eater bones");
        makingMasterBoss[2] = boss3M;
        bossIndexMaster++;
        stationaryMaster++;
        Boss eaterOfWorldsMasterSS = new Boss("Eater of worlds", true, 19_224, "Master");
        makingMasterAlteringStateBoss[2] = eaterOfWorldsMasterSS;

        Boss boss4M = new Boss("Brain of cthulhu", 7_029, "Master", true, "Brain in a jar, Brain of cthulhu relic, Brain of confusion, Brain of cthulhu mask, Crimtane ore, Tissue sample, Bone rattle");
        makingMasterBoss[3] = boss4M;
        bossIndexMaster++;
        stationaryMaster++;
        Boss brainOfCthulhuMasterSS = new Boss("Brain of cthulhu", true, 2_709, "Master");
        makingMasterAlteringStateBoss[3] = brainOfCthulhuMasterSS;

        Boss boss5M = new Boss("Queen bee", 6_069, "Master", true, "Sparkling honey, Queen bee relic, Hive pack, Queen bee mask, Bee gun, Bee keeper, The bee's knees, Honey comb, Nectar, Honeyed goggles, Hive wand");
        makingMasterBoss[4] = boss5M;
        bossIndexMaster++;
        stationaryMaster++;
        Boss queenBeeMasterSS = new Boss("Queen bee", true, 6_069, "Master");
        makingMasterAlteringStateBoss[4] = queenBeeMasterSS;

        Boss boss6M = new Boss("Skeletron", 11_220, "Master", true, "Possessed skull, Skeletron relic, Bone gloves, Skeletron mask, Book of skulls");
        makingMasterBoss[5] = boss6M;
        bossIndexMaster++;
        stationaryMaster++;
        Boss skeletronMasterSS = new Boss("Skeletron", true, 11_220, "Master");
        makingMasterAlteringStateBoss[5] = skeletronMasterSS;

        Boss boss7M = new Boss("Deerclops", 15_172, "Master", true, "Deerclops eyeball, Deerclops relic, Bone helm, Deerclops mask, Eye bone, Eyebrella, Radio thing, Dizzy's rare gecko chester, Pew-matic horn, Weather pain, Houndius shootuis, Lucy the axe");
        makingMasterBoss[6] = boss7M;
        bossIndexMaster++;
        stationaryMaster++;
        Boss deerclopsMasterSS = new Boss("Deerclops", true, 15_172, "Master");
        makingMasterAlteringStateBoss[6] = deerclopsMasterSS;

        Boss boss8M = new Boss("Wall of flesh", 14_280, "Master", true, "Goat skull, Wall of flesh relic, Demon heart, Wall of flesh mask, Pwnhammer, Warrior emblem, Ranger emblem, Sorcerer emblem, Summoners emblem, Breaker blade, Clockwork assault rifle, Laser rifle, Firecracker");
        makingMasterBoss[7] = boss8M;
        bossIndexMaster++;
        stationaryMaster++;
        Boss wallOfFleshMasterSS = new Boss("Wall of flesh", true, 14_280, "Master");
        makingMasterAlteringStateBoss[7] = wallOfFleshMasterSS;

        Boss boss9M = new Boss("Queen slime", 36_720, "Master", true, "Regal delicacy, Queen slime relic, Volatile getaltin, Sparkle slime balloon, Queen slime mask, Gelatinous pillion, Hook of dissonance, Blade staff, Crystal assassin hood, Crystal assassin shirt, Crystal assassin pants");
        makingMasterBoss[8] = boss9M;
        bossIndexMaster++;
        stationaryMaster++;
        Boss queenBeeExpertMasterSS = new Boss("Queen bee", true, 18_360, "Master");
        makingMasterAlteringStateBoss[8] = queenBeeExpertMasterSS;

        Boss boss10M = new Boss("The twins (Retinazar and Spazmatism)", 82_237, "Master", true, "Pair of eyeballs, Twins relic, Mechanical wheel piece, Twin mask, Soul of sight, Hallowed bar");
        makingMasterBoss[9] = boss10M;
        bossIndexMaster++;
        stationaryMaster++;
        Boss theTwinsMasterSS = new Boss("The twins (Retinazar and Spazmatism)", true, 41_118, "Master");
        makingMasterAlteringStateBoss[9] = theTwinsMasterSS;


        Boss boss11M = new Boss("The destroyer", 153_000, "Master", true, "Deactivated probe, Destroyer relic, Mechanical wagon piece, Destroyer mask, Soul of might, Hallowed bar");
        makingMasterBoss[10] = boss11M;
        bossIndexMaster++;
        stationaryMaster++;
        Boss theDestroyerMasterSS = new Boss("The destroyer", true, 153_000, "Master");
        makingMasterAlteringStateBoss[10] = theDestroyerMasterSS;

        Boss boss12M = new Boss("Skeletron prime", 53_550, "Master", true, "Robotic skull, Skeletron prime relic, Mechanical battery piece, Skeletron prime mask, Soul of fright, Hallowed bar");
        makingMasterBoss[11] = boss12M;
        bossIndexMaster++;
        stationaryMaster++;
        Boss skeletronPrimeMasterSS = new Boss("Skeletron prime", true, 53_550, "Master");
        makingMasterAlteringStateBoss[11] = skeletronPrimeMasterSS;

        Boss boss13M = new Boss("Plantera", 53_550, "Master", true, "Plantera seedling, Plantera relic, Spore sac, Plantera mask, Temple key, Grenade launcher, Venus magnum, Nettle burst, Leaf blower, Flower pow, Wasp gun, Seedler, Seedling, The axe, Pygmy staff, Thorn hook");
        makingMasterBoss[12] = boss13M;
        bossIndexMaster++;
        stationaryMaster++;
        Boss planteraMasterSS = new Boss("Plantera", true, 26_775, "Master");
        makingMasterAlteringStateBoss[12] = planteraMasterSS;

        Boss boss14M = new Boss("Golem", 114_749, "Master", true, "Guardian golem, Golem relic, Shiny stone, Golem mask, Picksaw, Stynger, Possessed hatchet, Sun stone, Eye of the golem, Picksaw, Heat ray, Staff of earth, Golem fist, Beetle husk");
        makingMasterBoss[13] = boss14M;
        bossIndexMaster++;
        stationaryMaster++;
        Boss golemMasterSS = new Boss("Golem", true, 57_374, "Master");
        makingMasterAlteringStateBoss[13] = golemMasterSS;

        Boss boss15M = new Boss("Duke fishron", 99_000, "Master", true, "Pork of the sea, Duke fishron relic, Shrimpy truffle, Duke fishron mask, Bubble gun, Flairon, Razorblade typhoon, Tempest staff, Tsunami, Fishron wings");
        makingMasterBoss[14] = boss15M;
        bossIndexMaster++;
        stationaryMaster++;
        Boss dukeFishronMasterSS = new Boss("Duke fishron", true, 49_500, "Master");
        makingMasterAlteringStateBoss[14] = dukeFishronMasterSS;


        Boss boss16M = new Boss("Empress of light", 124_950, "Master", true, "Jewel of light, Empress of light relic, Nightglow, Starlight, Kaleidoscope, Eventide, Soaring insignia, Empress of light mask, Empress wings, Stellar tune, Rainbow cursor, Prismatic dye");
        makingMasterBoss[15] = boss16M;
        bossIndexMaster++;
        stationaryMaster++;
        Boss empressOfLightMasterSS = new Boss("Empress of light", true, 62_475, "Master");
        makingMasterAlteringStateBoss[15] = empressOfLightMasterSS;

        Boss boss17M = new Boss("Lunatic cultist", 61_000, "Master", true, "Tablet fragment, Lunatic cultist relic");
        makingMasterBoss[16] = boss17M;
        bossIndexMaster++;
        stationaryMaster++;
        Boss lunaticCultistMasterSS = new Boss("Lunatic cultist", true, 61_000, "Master");
        makingMasterAlteringStateBoss[16] = lunaticCultistMasterSS;

        Boss boss18M = new Boss("Moon lord", 277_311, "Master", true, "Piece of moon squid, Moon lord relic, Gravity globe, Suspicious looking tentacle, Celestial starboard, Moon lord mask, Meowmere, Terrarian, Star wrath, S.D.M.G, Last prism, Lunar flare, Rainbow crystal staff, Lunar portal staff, Celebration mk2, Celebration, Portal gun, Luminite, Meowmere minecart");
        makingMasterBoss[17] = boss18M;
        bossIndexMaster++;
        stationaryMaster++;
        Boss moonLordMasterSS = new Boss("Moon lord", true, 277_311, "Master");
        makingMasterAlteringStateBoss[17] = moonLordMasterSS;
        return null;
    }

    public int getBossIndexNumber() {
        return bossIndexNumber;
    }

    public void setBossIndexNumber(int bossIndexNumber) {
        this.bossIndexNumber = bossIndexNumber;
    }

    public int getBossIndexExpert() {
        return bossIndexExpert;
    }

    public void setBossIndexExpert(int bossIndexExpert) {
        this.bossIndexExpert = bossIndexExpert;
    }

    public int getBossIndexMaster() {
        return bossIndexMaster;
    }

    public void setBossIndexMaster(int bossIndexMaster) {
        this.bossIndexMaster = bossIndexMaster;
    }

    public int getStationaryIndexNumber() {
        return stationaryIndexNumber;
    }

    public void setStationaryIndexNumber(int stationaryIndexNumber) {
        this.stationaryIndexNumber = stationaryIndexNumber;
    }
    public void addingNewBossToCheckList(){


    }


}
