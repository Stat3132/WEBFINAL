package com.example.terrariabosscreator;

public class InvalidRatingException extends IllegalArgumentException{
    public InvalidRatingException(String message){
        super(message);
    }
}
