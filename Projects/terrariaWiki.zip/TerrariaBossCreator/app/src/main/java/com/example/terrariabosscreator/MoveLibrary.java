package com.example.terrariabosscreator;

public class MoveLibrary {
    final int BOSSMAX = 18;
    Move[] makingBossMoveSet = new Move[BOSSMAX];
    Move[] makingExpertMoveSet = new Move[BOSSMAX];
    Move[] makingMasterMoveSet = new Move[BOSSMAX];
    Move[] makingAlteringBossMoveSet = new Move[BOSSMAX];
    Move[] makingExpertAlteringBossMoveSet = new Move[BOSSMAX];
    Move[] makingMasterAlteringBossMoveSet = new Move[BOSSMAX];
    public void creatingMoves() {
        Move kingSlime = new Move("Contact with slime: ", 40, "\u274C");
        makingBossMoveSet[0] = kingSlime;

        Move eyeOfCthulhu = new Move("Contact with The Eye Of Cthulhu: ", 15, "\u274C");
        makingBossMoveSet[1] = eyeOfCthulhu;
        Move eyeOfCthulhuSS = new Move("Contact with the eye Of Cthulhu: ", 23, "\u274C");
        makingAlteringBossMoveSet[1] = eyeOfCthulhuSS;

        Move eaterOfWorlds = new Move("Eater of worlds head damage: ", 22, "\u274C", "Eater of worlds body contact damage: ", 13, "\u274C", "Vile spit projectile", 11, "Weak");
        makingBossMoveSet[2] = eaterOfWorlds;

        Move brainOfCthulu = new Move("Brain of cthulhu contact damage: ", 30, "\u274C");
        makingBossMoveSet[3] = brainOfCthulu;

        Move queenBee = new Move("Queen bee contact damage: ", 30, "\u274C", "Queen bee stinger: ", 22, "Poison");
        makingBossMoveSet[4] = queenBee;

        Move skeletron = new Move("Skeletron contact damage: ", 32, "Bleeding", "Skeletron arm damage: ", 20, "Slow", "Skeletrons head in the day: ", 1000, "\u274C");
        makingBossMoveSet[5] = skeletron;

        Move deerclops = new Move("Deerclops contact damage: ", 20, "\u274C", "Ice spike: ", 26, "Frozen", "Debris damage: ", 36, "\u274C", "Shadow hands: ", 20, "\u274C", "Deerclops roar:", 0, "Slow");
        makingBossMoveSet[6] = deerclops;

        Move wallOfFlesh = new Move("Wall of flesh contact damage: ", 50, "Horrified", "Wall of flesh lasers: ", 30, "Horrified");
        makingBossMoveSet[7] = wallOfFlesh;

        Move queenSlime = new Move("Queen slime contact damage: ", 60, "\u274C", "Queenly smash:", 80, "\u274C", "Regal gel:", 60, "Sparkle slime");
        makingBossMoveSet[8] = queenSlime;

        Move theTwins = new Move("(Retinazar) Contact damage: ", 40, "\u274C", "(Retinazar) Eye laser: ", 40, "\u274C", "(Spazmatism) Contact damage: ", 50, "Cursed inferno", "(Spazmatism) Cursed flames:", 50, "Cursed inferno");
        makingBossMoveSet[9] = theTwins;
        Move theTwinsSS = new Move("(Retinazar) Contact damage: ", 67, "\u274C", "(Retinazar) Death laser: ", 50, "\u274C", "(Retinazar) Rapid fire: ", 36, "\u274C", "(Spazmatism) Contact damage: ", 75, "Cursed inferno", "(Spazmatis) Eye fire: ", 60, "Cursed inferno");
        makingAlteringBossMoveSet[9] = theTwinsSS;

        Move theDestroyer = new Move("The destroyer head contact damage: ", 70, "\u274C", "The destroyer body contact damage: ", 55, "\u274C", "Death laser: ", 44, "\u274C", "Destroyer tail contact: ", 40, "\u274C");
        makingBossMoveSet[10] = theDestroyer;

        Move skeletronPrime = new Move("Skeletron prime head damage: ", 47, "\u274C", "Prime cannon bomb damage: ", 50, "\u274C", "Prime saw contact damage: ", 56, "\u274C", "Prime vice contact damage: ", 52, "\u274C", "Prime laser damage: ", 50, "\u274C");
        makingBossMoveSet[11] = skeletronPrime;

        Move plantera = new Move("Plantera contact damage: ", 50, "\u274C", "Plantera seed damage: ", 44, "\u274C", "Poison seed damage", 54, "Poison", "Thorn ball damage: ", 62, "Poison");
        makingBossMoveSet[12] = plantera;
        Move planteraSS = new Move("Plantera contact damage: ", 70, "Poison seed", "Plantera hook: ", 60, "Poison seed", "Plantera tentacle damage: ", 60, "Poison", "Plantera spore's: ", 70, "Poison");
        makingAlteringBossMoveSet[12] = planteraSS;

        Move golem = new Move("Golem head contact damage: ", 64, "\u274C", "Golem head fireball damage: ", 36, "On fire", "Golem head eye beams: ", 56, "\u274C", "Golem fist damage: ", 56, "\u274C");
        makingBossMoveSet[13] = golem;
        Move golemSS = new Move("Golem body contact damage: ", 72, "\u274C", "Golem head contact damage: ", 80, "\u274C");
        makingAlteringBossMoveSet[13] = golemSS;

        Move dukeFishron = new Move("Duke fishron contact damage: ", 100, "\u274C", "Sharknado: ", 80, "\u274C", "Detonating bubbles: ", 100, "\u274C");
        makingBossMoveSet[14] = dukeFishron;
        Move dukeFishronSS = new Move("Duke fishron contact damage: ", 120, "\u274C", "Duke fishron enraged contact damage: ", 200, "\u274C", "Cthulunado", 160, "\u274C");
        makingAlteringBossMoveSet[14] = dukeFishronSS;

        Move empressOfLight = new Move("Empress of light contact damage: ", 80, "\u274C", "Empress of light dash: ", 120, "\u274C", "Prismatic bolt: ", 90, "\u274C", "Sun dance: ", 100, "\u274C", "Ethereal lance: ", 100, "\u274C");
        makingBossMoveSet[15] = empressOfLight;
        Move empressOfLightSS = new Move("Prismatic bolt: ", 100, "\u274C", "Sun dance: ", 120, "\u274C", "Everlasting rainbow: ", 100, "\u274C", "Etheral lance: ", 120, "\u274C", "Etheral lance V2: ", 130, "\u274C");
        makingAlteringBossMoveSet[15] = empressOfLightSS;

        Move lunaticCultist = new Move("Lunatic cultist contact damage: ", 50, "\u274C", "Shadow fireball: ", 36, "On fire", "Ice mist: ", 70, "\u274C", "Fire ball: ", 60, "On fire", "Ancient light: ", 120, "\u274C");
        makingBossMoveSet[16] = lunaticCultist;

        Move moonLord = new Move("Phantasmal deathray: ", 150, "Moon bite", "Moon lord open hand damage: ", 80, "Moon bite", "Phantasmal sphere: ", 80, "Moon bite", "Phantasmal eye: ", 60, "Moon bite", "Phantasmal bolt: ", 60, "Moon bite");
        makingBossMoveSet[17] = moonLord;



        //TODO: EXPERT BOSS


        Move expertkingSlime = new Move("Contact with slime: ", 64, "\u274C");
        makingExpertMoveSet[0] = expertkingSlime;

        Move expertEyeOfCthulhu = new Move("Contact with The Eye Of Cthulhu: ", 30, "\u274C");
        makingExpertMoveSet[1] = expertEyeOfCthulhu;
        Move expertEyeOfCthulhuSS = new Move("Contact with the eye Of Cthulhu: ", 36, "\u274C", "Contact damage if below 145 health: ", 40, "\u274C");
        makingExpertAlteringBossMoveSet[1] = expertEyeOfCthulhuSS;

        Move expertEaterOfWorlds = new Move("Eater of worlds head damage: ",48 , "\u274C", "Eater of worlds body contact damage: ", 25, "\u274C", "Vile spit projectile", 17, "Weak");
        makingExpertMoveSet[2] = expertEaterOfWorlds;

        Move expertBrainOfCthulu = new Move("Brain of cthulhu contact damage: ", 54, "\u274C");
        makingExpertMoveSet[3] = expertBrainOfCthulu;

        Move expertQueenBee = new Move("Queen bee contact damage: ", 54, "\u274C", "Queen bee stinger: ", 44, "Poison");
        makingExpertMoveSet[4] = expertQueenBee;

        Move expertSkeletron = new Move("Skeletron contact damage: ", 70, "Bleeding", "Skeletron arm damage: ", 44, "Slow", "Skeletrons head in the day: ", 1000, "\u274C");
        makingExpertMoveSet[5] = expertSkeletron;

        Move expertDeerclops = new Move("Deerclops contact damage: ", 40, "\u274C", "Ice spike: ", 52, "Frozen", "Debris damage: ", 72, "\u274C", "Shadow hands: ", 40, "\u274C", "Deerclops roar:", 0, "Slow");
        makingExpertMoveSet[6] = expertDeerclops;

        Move expertWallOfFlesh = new Move("Wall of flesh contact damage: ", 150, "Horrified", "Wall of flesh lasers: ", 60, "Horrified");
        makingExpertMoveSet[7] = expertWallOfFlesh;

        Move expertQueenSlime = new Move("Queen slime contact damage: ", 120, "\u274C", "Queenly smash:", 160, "\u274C", "Regal gel:", 120, "Sparkle slime");
        makingExpertMoveSet[8] = expertQueenSlime;

        Move expertTheTwins = new Move("(Retinazar) Contact damage: ", 76, "\u274C", "(Retinazar) Eye laser: ", 76, "\u274C", "(Spazmatism) Contact damage: ", 85, "Cursed inferno", "(Spazmatism) Cursed flames:", 88, "Cursed inferno");
        makingExpertMoveSet[9] = expertTheTwins;
        Move expertTheTwinsSS = new Move("(Retinazar) Contact damage: ", 114, "\u274C", "(Retinazar) Death laser: ", 92, "\u274C", "(Retinazar) Rapid fire: ", 68, "\u274C", "(Spazmatism) Contact damage: ", 127, "Cursed inferno", "(Spazmatis) Eye fire: ", 108, "Cursed inferno");
        makingExpertAlteringBossMoveSet[9] = expertTheTwinsSS;

        Move expertTheDestroyer = new Move("The destroyer head contact damage: ", 280, "\u274C", "The destroyer body contact damage: ", 93, "\u274C", "Death laser: ", 72, "\u274C", "Destroyer tail contact: ", 68, "\u274C");
        makingExpertMoveSet[10] = expertTheDestroyer;

        Move expertSkeletronPrime = new Move("Skeletron prime head damage: ", 79, "\u274C", "Prime cannon bomb damage: ", 160, "\u274C", "Prime saw contact damage: ", 95, "\u274C", "Prime vice contact damage: ", 88, "\u274C", "Prime laser damage: ", 100, "\u274C");
        makingExpertMoveSet[11] = expertSkeletronPrime;

        Move expertPlantera = new Move("Plantera contact damage: ", 100, "\u274C", "Plantera seed damage: ", 76, "\u274C", "Poison seed damage", 96, "Poison", "Thorn ball damage: ", 108, "Poison");
        makingExpertMoveSet[12] = expertPlantera;
        Move expertPlanteraSS = new Move("Plantera contact damage: ", 140, "Poison seed", "Plantera hook: ", 76, "Poison seed", "Plantera tentacle damage: ", 108, "Poison", "Plantera spore's: ", 90, "Poison");
        makingExpertAlteringBossMoveSet[12] = expertPlanteraSS;

        Move expertGolem = new Move("Golem head contact damage: ", 102, "\u274C", "Golem head fireball damage: ", 72, "On fire", "Golem head eye beams: ", 112, "\u274C", "Golem fist damage: ", 94, "\u274C");
        makingExpertMoveSet[13] = expertGolem;
        Move expertGolemSS = new Move("Golem body contact damage: ", 115, "\u274C", "Golem head contact damage: ", 128, "\u274C");
        makingExpertAlteringBossMoveSet[13] = expertGolemSS;

        Move expertDukeFishron = new Move("Duke fishron contact damage: ", 140, "\u274C", "Sharknado: ", 100, "\u274C", "Detonating bubbles: ", 150, "\u274C");
        makingExpertMoveSet[14] = expertDukeFishron;
        Move expertDukeFishronSS = new Move("Duke fishron contact damage: ", 201, "\u274C", "Duke fishron enraged contact damage: ", 280, "\u274C", "Cthulunado", 200, "\u274C", "Contact on third stage: ", 184, "Bleed");
        makingExpertAlteringBossMoveSet[14] = expertDukeFishronSS;

        Move expertEmpressOfLight = new Move("Empress of light contact damage: ", 110, "\u274C", "Empress of light dash: ", 165, "\u274C", "Prismatic bolt: ", 120, "\u274C", "Sun dance: ", 140, "\u274C", "Ethereal lance: ", 120, "\u274C");
        makingExpertMoveSet[15] = expertEmpressOfLight;
        Move expertEmpressOfLightSS = new Move("Prismatic bolt: ", 140, "\u274C", "Sun dance: ", 160, "\u274C", "Everlasting rainbow: ", 140, "\u274C", "Etheral lance: ", 140, "\u274C", "Etheral lance V2: ", 120, "\u274C");
        makingExpertAlteringBossMoveSet[15] = expertEmpressOfLightSS;

        Move expertLunaticCultist = new Move("Lunatic cultist contact damage: ", 75, "\u274C", "Shadow fireball: ", 72, "On fire", "Ice mist: ", 100, "\u274C", "Fire ball: ", 80, "On fire", "Ancient light: ", 160, "\u274C");
        makingExpertMoveSet[16] = expertLunaticCultist;

        Move expertMoonLord = new Move("Phantasmal deathray: ", 300, "Moon bite", "Moon lord open hand damage: ", 80, "Moon bite", "Phantasmal sphere: ", 160, "Moon bite", "Phantasmal eye: ", 120, "Moon bite", "Phantasmal bolt: ", 120, "Moon bite");
        makingExpertMoveSet[17] = expertMoonLord;


        // TODO:MASTER BOSS


        Move masterKingSlime = new Move("Contact with slime: ", 96, "\u274C");
        makingMasterMoveSet[0] = masterKingSlime;

        Move masterEyeOfCthulhu = new Move("Contact with The Eye Of Cthulhu: ", 45, "\u274C");
        makingMasterMoveSet[1] = masterEyeOfCthulhu;
        Move masterEyeOfCthulhuSS = new Move("Contact with the eye Of Cthulhu: ", 54, "\u274C", "Contact damage if below 185 health: ", 60, "\u274C" );
        makingMasterAlteringBossMoveSet[1] = masterEyeOfCthulhuSS;

        Move masterEaterOfWorlds = new Move("Eater of worlds head damage: ", 72, "\u274C", "Eater of worlds body contact damage: ", 31, "\u274C", "Vile spit projectile", 26, "Weak");
        makingMasterMoveSet[2] = masterEaterOfWorlds;

        Move masterBrainOfCthulu = new Move("Brain of cthulhu contact damage: ", 81, "\u274C");
        makingMasterMoveSet[3] = masterBrainOfCthulu;

        Move masterQueenBee = new Move("Queen bee contact damage: ", 81, "\u274C", "Queen bee stinger: ", 66, "Poison");
        makingMasterMoveSet[4] = masterQueenBee;

        Move masterSkeletron = new Move("Skeletron contact damage: ", 105, "Bleeding", "Skeletron arm damage: ", 66, "Slow", "Skeletrons head in the day: ", 1000, "\u274C");
        makingMasterMoveSet[5] = masterSkeletron;

        Move masterDeerclops = new Move("Deerclops contact damage: ", 60, "\u274C", "Ice spike: ", 78, "Frozen", "Debris damage: ", 108, "\u274C", "Shadow hands: ", 60, "\u274C", "Deerclops roar:", 0, "Slow");
        makingMasterMoveSet[6] = masterDeerclops;

        Move masterWallOfFlesh = new Move("Wall of flesh contact damage: ", 225, "Horrified", "Wall of flesh lasers: ", 90, "Horrified");
        makingMasterMoveSet[7] = masterWallOfFlesh;

        Move masterQueenSlime = new Move("Queen slime contact damage: ", 180, "\u274C", "Queenly smash:", 240, "\u274C", "Regal gel:", 180, "Sparkle slime");
        makingMasterMoveSet[8] = masterQueenSlime;

        Move masterTheTwins = new Move("(Retinazar) Contact damage: ", 114, "\u274C", "(Retinazar) Eye laser: ", 114, "\u274C", "(Spazmatism) Contact damage: ", 127, "Cursed inferno", "(Spazmatism) Cursed flames:", 132, "Cursed inferno");
        makingMasterMoveSet[9] = masterTheTwins;
        Move masterTheTwinsSS = new Move("(Retinazar) Contact damage: ", 171, "\u274C", "(Retinazar) Death laser: ", 138, "\u274C", "(Retinazar) Rapid fire: ", 102, "\u274C", "(Spazmatism) Contact damage: ", 190, "Cursed inferno", "(Spazmatis) Eye fire: ", 162, "Cursed inferno");
        makingMasterAlteringBossMoveSet[9] = masterTheTwinsSS;

        Move masterTheDestroyer = new Move("The destroyer head contact damage: ", 420, "\u274C", "The destroyer body contact damage: ", 140, "\u274C", "Death laser: ", 108, "\u274C", "Destroyer tail contact: ", 102, "\u274C");
        makingMasterMoveSet[10] = masterTheDestroyer;

        Move masterSkeletronPrime = new Move("Skeletron prime head damage: ", 119, "\u274C", "Prime cannon bomb damage: ", 240, "\u274C", "Prime saw contact damage: ", 142, "\u274C", "Prime vice contact damage: ", 132, "\u274C", "Prime laser damage: ", 150, "\u274C");
        makingMasterMoveSet[11] = masterSkeletronPrime;

        Move masterPlantera = new Move("Plantera contact damage: ", 150, "\u274C", "Plantera seed damage: ", 114, "\u274C", "Poison seed damage", 144, "Poison", "Thorn ball damage: ", 162, "Poison");
        makingMasterMoveSet[12] = masterPlantera;
        Move masterPlanteraSS = new Move("Plantera contact damage: ", 210, "Poison seed", "Plantera hook: ", 90, "Poison seed", "Plantera tentacle damage: ", 162, "Poison", "Plantera spore's: ", 114, "Poison");
        makingMasterAlteringBossMoveSet[12] = masterPlanteraSS;

        Move masterGolem = new Move("Golem head contact damage: ", 153, "\u274C", "Golem head fireball damage: ", 174, "On fire", "Golem head eye beams: ", 168, "\u274C", "Golem fist damage: ", 141, "\u274C");
        makingMasterMoveSet[13] = masterGolem;
        Move masterGolemSS = new Move("Golem body contact damage: ", 172, "\u274C", "Golem head contact damage: ", 192, "\u274C");
        makingMasterAlteringBossMoveSet[13] = masterGolemSS;

        Move masterDukeFishron = new Move("Duke fishron contact damage: ", 210, "\u274C", "Sharknado: ", 150, "\u274C", "Detonating bubbles: ", 225, "\u274C");
        makingMasterMoveSet[14] = masterDukeFishron;
        Move masterDukeFishronSS = new Move("Duke fishron contact damage: ", 120, "\u274C", "Duke fishron enraged contact damage: ", 200, "\u274C", "Cthulunado", 160, "\u274C");
        makingMasterAlteringBossMoveSet[14] = masterDukeFishronSS;

        Move masterEmpressOfLight = new Move("Empress of light contact damage: ", 165, "\u274C", "Empress of light dash: ", 248, "\u274C", "Prismatic bolt: ", 180, "\u274C", "Sun dance: ", 210, "\u274C", "Ethereal lance: ", 180, "\u274C");
        makingMasterMoveSet[15] = masterEmpressOfLight;
        Move masterEmpressOfLightSS = new Move("Prismatic bolt: ", 210, "\u274C", "Sun dance: ", 240, "\u274C", "Everlasting rainbow: ", 210, "\u274C", "Etheral lance: ", 210, "\u274C", "Etheral lance V2: ", 180, "\u274C");
        makingMasterAlteringBossMoveSet[15] = masterEmpressOfLightSS;

        Move masterLunaticCultist = new Move("Lunatic cultist contact damage: ", 112, "\u274C", "Shadow fireball: ", 72, "On fire", "Ice mist: ", 100, "\u274C", "Fire ball: ", 80, "On fire", "Ancient light: ", 160, "\u274C");
        makingMasterMoveSet[16] = masterLunaticCultist;

        Move masterMoonLord = new Move("Phantasmal deathray: ", 450, "Moon bite", "Moon lord open hand damage: ", 80, "Moon bite", "Phantasmal sphere: ", 240, "Moon bite", "Phantasmal eye: ", 180, "Moon bite", "Phantasmal bolt: ", 180, "Moon bite");
        makingMasterMoveSet[17] = masterMoonLord;
    }
}
