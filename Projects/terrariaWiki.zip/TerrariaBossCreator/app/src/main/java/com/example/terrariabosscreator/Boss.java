package com.example.terrariabosscreator;

import java.net.BindException;

public class Boss {
    private int health;
    private String name;
    private int moveListCounter = 0;
    private String drops;
    private String lootBagDrogs;
    private boolean ifDroppedLootBag;
    private String summonBoss;
    private boolean onSecondForm;
    private String difficulty;
    private boolean isEnraged;


    // SECOND FORM CONSTRUCTOR
    public Boss(String name, boolean onSecondForm, int health, String difficulty) {
        setName(name);
        setOnSecondForm(onSecondForm);
        setHealth(health);
        setDifficulty(difficulty);

    }

    //NORMAL BOSS INFORMATION
    public Boss(String name, int health, boolean onSecondForm, String difficulty, boolean ifDroppedLootBag, String drops, String lootBagDrogs, String summonBoss)  {
        setName(name);
        setHealth(health);
        setOnSecondForm(onSecondForm);
        setDifficulty(difficulty);
        setIfDroppedLootBag(ifDroppedLootBag);
        setDrops(drops);
        setLootBagDrogs(lootBagDrogs);
        setEnraged(isEnraged);
        setSummonBoss(summonBoss);



    }
    //EXPERT and MASTER BOSS INFORMATION
    public Boss(String name, int health, String difficulty, boolean ifDroppedLootBag, String lootBagDrogs)  {
        setName(name);
        setHealth(health);
        setDifficulty(difficulty);
        setIfDroppedLootBag(ifDroppedLootBag);
        setLootBagDrogs(lootBagDrogs);

    }

    public int getHealth() {
        return health;
    }

    public void setHealth(int health) {
        if (health != 0 && health <= 277_311) {
            this.health = health;
        }
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        if (name != null) {
            this.name = name;
        }
    }

    public String getDrops() {
        return drops;
    }

    public void setDrops(String drops) {
        if (drops != null) {
            this.drops = drops;
        }
    }

    public boolean isIfDroppedLootBag() {
        return ifDroppedLootBag;
    }

    public void setIfDroppedLootBag(boolean ifDroppedLootBag) {
        this.ifDroppedLootBag = ifDroppedLootBag;
    }

    public boolean isOnSecondForm() {
        return onSecondForm;
    }

    private void setOnSecondForm(boolean onSecondForm) {
        this.onSecondForm = onSecondForm;
    }

    public String getDifficulty() {
        return difficulty;
    }

    public void setDifficulty(String difficulty) {
        if (difficulty != null) {
            this.difficulty = difficulty;
        }
    }

    public boolean isEnraged() {
        return isEnraged;
    }

    private void setEnraged(boolean enraged) {
        isEnraged = enraged;
    }

    public String getSummonBoss() {
        return summonBoss;
    }

    private void setSummonBoss(String summonBoss) {
        if (summonBoss != null) {
            this.summonBoss = summonBoss;
        }
    }

    public String getLootBagDrogs() {
        return lootBagDrogs;
    }

    public void setLootBagDrogs(String lootBagDrogs) {
        if (lootBagDrogs != null) {
            this.lootBagDrogs = lootBagDrogs;
        }
    }
    @Override
    public String toString() {
        StringBuilder bossString = new StringBuilder();
        if (name != null) {
            bossString.append("\t").append(getName()).append("\n\n");
        }
        if (health != 0) {
            bossString.append(isOnSecondForm() ? "\tHealth to get to second stage:" : "\tHealth:").append(getHealth()).append(" ").append("\u2764\uFE0F").append("\n\n").append("\t").append(isOnSecondForm() ? "Second stage:\n" + "This is where the fun begins" + "\t \uD83D\uDC7F" + "\n\n" : "Stage one:" + " " + "We are still at base stage" + "\t \u0031\u20E3" + "\n" + (isEnraged ? "Boss does extra damage be carefull" + "\n\n" : "The boss isnt as harmful but be careful" + "\n\n"));
        }
        if (difficulty != null) {
            bossString.append("\tDifficulty:").append(getDifficulty()).append("\n\n");
        }
        if (drops != null) {
            bossString.append("\tDrops:").append(getDrops()).append("\n\n");
        }
        if (lootBagDrogs != null) {
            bossString.append("\tLoot bag contents:\n").append((isIfDroppedLootBag() ? "\n" + lootBagDrogs + "\u2714" + "\n\n" : "No loot bag for normal" + "\u274C" + "\n\n" + "Loot bags ONLY in Expert and Master mode (Currently on normal)" + "\n\n"));
        }
        if (summonBoss != null) {
            bossString.append("\tTo summon boss:").append("").append(getSummonBoss()).toString();
        }
        return bossString.toString();
    }


}
