package com.example.terrariabosscreator;

public class CheckListArray {
    private int checkListCount;
     CheckList[] libraryOfCheckLists = new CheckList[100];
    public void ifThereIsABossInputtedAlready(){

    }
}
