package com.example.terrariabosscreator;

public class InvalidDifficultyException extends IllegalArgumentException{
    public InvalidDifficultyException(String message){
        super(message);
    }
}
