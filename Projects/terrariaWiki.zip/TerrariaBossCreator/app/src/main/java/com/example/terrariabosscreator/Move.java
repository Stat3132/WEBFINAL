package com.example.terrariabosscreator;

public class Move {
    private String bossMoveNames, bossMoveNames2, bossMoveNames3, bossMoveNames4, bossMoveNames5;
    private int damage, damage2, damage3, damage4, damage5;
    private String debuff, debuff2, debuff3, debuff4, debuff5;

    public Move(String bossMoveNames, int damage, String debuff){
        setBossMoveNames(bossMoveNames);
        setDamage(damage);
        setDebuff(debuff);
    }
    public Move(String bossMoveNames, int damage, String debuff, String bossMoveNames2, int damage2, String debuff2){
        setBossMoveNames(bossMoveNames);
        setDamage(damage);
        setDebuff(debuff);
        setBossMoveNames2(bossMoveNames2);
        setDamage2(damage2);
        setDebuff2(debuff2);
    }
    public Move(String bossMoveNames, int damage, String debuff, String bossMoveNames2, int damage2, String debuff2, String bossMoveNames3, int damage3, String debuff3){
        setBossMoveNames(bossMoveNames);
        setDamage(damage);
        setDebuff(debuff);
        setBossMoveNames2(bossMoveNames2);
        setDamage2(damage2);
        setDebuff2(debuff2);
        setBossMoveNames3(bossMoveNames3);
        setDamage3(damage3);
        setDebuff3(debuff3);
    }
    public Move(String bossMoveNames, int damage, String debuff, String bossMoveNames2, int damage2, String debuff2, String bossMoveNames3, int damage3, String debuff3, String bossMoveNames4, int damage4, String debuff4){
        setBossMoveNames(bossMoveNames);
        setDamage(damage);
        setDebuff(debuff);
        setBossMoveNames2(bossMoveNames2);
        setDamage2(damage2);
        setDebuff2(debuff2);
        setBossMoveNames3(bossMoveNames3);
        setDamage3(damage3);
        setDebuff3(debuff3);
        setBossMoveNames4(bossMoveNames4);
        setDamage4(damage4);
        setDebuff4(debuff4);
    }
    public Move(String bossMoveNames, int damage, String debuff, String bossMoveNames2, int damage2, String debuff2, String bossMoveNames3, int damage3, String debuff3, String bossMoveNames4, int damage4, String debuff4, String bossMoveNames5, int damage5, String debuff5){
        setBossMoveNames(bossMoveNames);
        setDamage(damage);
        setDebuff(debuff);
        setBossMoveNames2(bossMoveNames2);
        setDamage2(damage2);
        setDebuff2(debuff2);
        setBossMoveNames3(bossMoveNames3);
        setDamage3(damage3);
        setDebuff3(debuff3);
        setBossMoveNames4(bossMoveNames4);
        setDamage4(damage4);
        setDebuff4(debuff4);
        setBossMoveNames5(bossMoveNames5);
        setDamage5(damage5);
        setDebuff5(debuff5);



    }





    public String getBossMoveNames() {
        return bossMoveNames;
    }

    public void setBossMoveNames(String bossMoveNames) {
        if (bossMoveNames != null){
        this.bossMoveNames = bossMoveNames;
        }
    }

    public String getBossMoveNames2() {
        return bossMoveNames2;
    }

    public void setBossMoveNames2(String bossMoveNames2) {
        if (bossMoveNames2 != null){
        this.bossMoveNames2 = bossMoveNames2;
        }

    }

    public String getBossMoveNames3() {
        return bossMoveNames3;
    }

    public void setBossMoveNames3(String bossMoveNames3) {
        if (bossMoveNames3 != null){
        this.bossMoveNames3 = bossMoveNames3;
        }
    }

    public String getBossMoveNames4() {
        return bossMoveNames4;
    }

    public void setBossMoveNames4(String bossMoveNames4) {
        if (bossMoveNames4 != null){
        this.bossMoveNames4 = bossMoveNames4;
        }
    }

    public String getBossMoveNames5() {
        return bossMoveNames5;
    }

    public void setBossMoveNames5(String bossMoveNames5) {
        if (bossMoveNames5 != null){
        this.bossMoveNames5 = bossMoveNames5;
        }
    }

    public int getDamage() {
        return damage;
    }

    private void setDamage(int damage) {
        if (damage <= 450){
        this.damage = damage;}
    }

    public int getDamage2() {
        return damage2;
    }

    public void setDamage2(int damage2) {
        if (damage2 <= 450){
        this.damage2 = damage2;}
    }

    public int getDamage3() {
        return damage3;
    }

    public void setDamage3(int damage3) {
        if (damage3 <= 450){
        this.damage3 = damage3;
        }
    }

    public int getDamage4() {
        return damage4;
    }

    public void setDamage4(int damage4) {
        if (damage4 <= 450){
        this.damage4 = damage4;
        }
    }

    public int getDamage5() {
        return damage5;
    }

    public void setDamage5(int damage5) {
        if (damage5 <= 450){
        this.damage5 = damage5;
        }
    }

    public String getDebuff() {
        return debuff;
    }


    private void setDebuff(String debuff) {
        if (debuff != null){
        this.debuff = debuff;}
    }

    public String getDebuff2() {
        return debuff2;
    }

    public void setDebuff2(String debuff2) {
        if (debuff2 != null){
        this.debuff2 = debuff2;
        }
    }

    public String getDebuff3() {
        return debuff3;
    }

    public void setDebuff3(String debuff3) {
        if (debuff3 != null){
        this.debuff3 = debuff3;
        }
    }

    public String getDebuff4() {
        return debuff4;
    }

    public void setDebuff4(String debuff4) {
        if (debuff4 != null){
        this.debuff4 = debuff4;
        }
    }

    public String getDebuff5() {
        return debuff5;
    }

    public void setDebuff5(String debuff5) {
        if (debuff5 != null){
        this.debuff5 = debuff5;
        }
    }

    @Override
    public String toString() {
        StringBuilder bossMoves = new StringBuilder();
     if (bossMoveNames5 != null){
         bossMoves.append("\t").append("Boss's moves: ").append("\n");
        bossMoves.append("\t\t").append(bossMoveNames).append("\n").append("Damage: ").append(damage).append("\n").append("Status affect: ").append(debuff).append("\n\n");
        bossMoves.append("\t\t").append(bossMoveNames2).append("\n").append("Damage: ").append(damage2).append("\n").append("Status affect: ").append(debuff2).append("\n\n");
        bossMoves.append("\t\t").append(bossMoveNames3).append("\n").append("Damage: ").append(damage3).append("\n").append("Status affect: ").append(debuff3).append("\n\n");
        bossMoves.append("\t\t").append(bossMoveNames4).append("\n").append("Damage: ").append(damage4).append("\n").append("Status affect: ").append(debuff4).append("\n\n");
        bossMoves.append("\t\t").append(bossMoveNames5).append("\n").append("Damage: ").append(damage5).append("\n").append("Status affect: ").append(debuff5).append("\n\n");
    } else if (bossMoveNames4 != null){
         bossMoves.append("\t").append("Boss's moves: ").append("\n");
        bossMoves.append("\t\t").append(bossMoveNames).append("\n").append("Damage: ").append(damage).append("\n").append("Status affect: ").append(debuff).append("\n\n");
        bossMoves.append("\t\t").append(bossMoveNames2).append("\n").append("Damage: ").append(damage2).append("\n").append("Status affect: ").append(debuff2).append("\n\n");
        bossMoves.append("\t\t").append(bossMoveNames3).append("\n").append("Damage: ").append(damage3).append("\n").append("Status affect: ").append(debuff3).append("\n\n");
        bossMoves.append("\t\t").append(bossMoveNames4).append("\n").append("Damage: ").append(damage4).append("\n").append("Status affect: ").append(debuff4).append("\n\n");
     } else if (bossMoveNames3 != null){
         bossMoves.append("\t").append("Boss's moves: ").append("\n");
         bossMoves.append("\t\t").append(bossMoveNames).append("\n").append("Damage: ").append(damage).append("\n").append("Status affect: ").append(debuff).append("\n\n");
         bossMoves.append("\t\t").append(bossMoveNames2).append("\n").append("Damage: ").append(damage2).append("\n").append("Status affect: ").append(debuff2).append("\n\n");
         bossMoves.append("\t\t").append(bossMoveNames3).append("\n").append("Damage: ").append(damage3).append("\n").append("Status affect: ").append(debuff3).append("\n\n");
     } else if (bossMoveNames2 != null) {
         bossMoves.append("\t").append("Boss's moves: ").append("\n");
         bossMoves.append("\t\t").append(bossMoveNames).append("\n").append("Damage: ").append(damage).append("\n").append("Status affect: ").append(debuff).append("\n\n");
         bossMoves.append("\t\t").append(bossMoveNames2).append("\n").append("Damage: ").append(damage2).append("\n").append("Status affect: ").append(debuff2).append("\n\n");
     } else if (bossMoveNames != null) {
         bossMoves.append("\t").append("Boss's moves: ").append("\n");
         bossMoves.append("\t\t").append(bossMoveNames).append("\n").append("Damage: ").append(damage).append("\n").append("Status affect: ").append(debuff).append("\n\n");
     }
        return bossMoves.toString();
    }

}
