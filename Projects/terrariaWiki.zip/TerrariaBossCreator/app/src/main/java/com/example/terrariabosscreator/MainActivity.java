package com.example.terrariabosscreator;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;

import java.nio.channels.ScatteringByteChannel;

public class MainActivity extends AppCompatActivity {
    final int BOSSMAXAMOUNT = 18;
    // BOSS WIKI
    private TextView displayBossInfo;
    //BOSS CHECKLIST
    TextView displayCheckList;
    EditText bossName, difficultyCompleted, rating;
    ImageView kingSlime, eyeOfCthulhu, eaterOfWorlds, brainOfCthulhu, queenBee, skeletron, deerClops, wallOfFlesh, queenSlime, theTwins, theDestroyer, skeletronPrime, plantera, golem, dukeFishron, empressOfLight, lunaticCultist, moonLord, terrariaLogo;
    ImageView eyeOfCthuluSS, brainOfCthulhuSS, queenSlimeSS, theTwinsSS, planteraSS, golemSS, dukeFishronSS, empressOfLightSS;
    Button complete, search, normal, expert, master, firstStage, secondStage, previous, previousE, previousM, next, nextE, nextM, showAttacks, showBossInfo;
    ImageButton start, bossCheckList;
    // Max bosses in Terraria
    Boss[] normalBosses = new Boss[BOSSMAXAMOUNT];
    Boss[] expertBoss = new Boss[BOSSMAXAMOUNT];
    Boss[] masterBoss = new Boss[BOSSMAXAMOUNT];
    Boss[] alteringStateBoss = new Boss[BOSSMAXAMOUNT];
    Boss[] alteringExpertStateBoss = new Boss[BOSSMAXAMOUNT];
    Boss[] alteringMasterStateBoss = new Boss[BOSSMAXAMOUNT];
    //Boss moves for Normal
    Move[] bossMoveSet = new Move[BOSSMAXAMOUNT];
    //Boss moves for Expert
    Move[] expertMoveSet = new Move[BOSSMAXAMOUNT];
    //Boss moves for Master
    Move[] masterMoveSet = new Move[BOSSMAXAMOUNT];
    //Boss moves for second form Normal
    Move[] alteringBossMoveSet = new Move[BOSSMAXAMOUNT];
    //Boss moves for second form Expert
    Move[] alteringExpertBossMoveSet = new Move[BOSSMAXAMOUNT];
    //Boss moves for second form Master
    Move[] alteringMasterBossMoveSet = new Move[BOSSMAXAMOUNT];
    CheckList[] libraryOfCheckLists;
    //INSTANCES OF CLASSES TO ACCESS BOSS AND MOVE INFORMATION
    BossLibrary bossLibrary = new BossLibrary();
    MoveLibrary moveLibrary = new MoveLibrary();

    //These number says how many bosses are in the array which should stay as 34, as thats the max
    private int bossIndexNumber = 0;
    private int bossIndexExpert = 0;
    private int bossIndexMaster = 0;
    // The variable below moves this is used for previous and next
    private int movingIndexNumber = 0;
    private int checkListCount;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initView();
        bossLibrary.creatingBosses();
    }

    private void initView() {
        // BOSSLIBRARY INITIALIZATION
        bossLibrary.makingBosses = normalBosses;
        bossLibrary.makingExpertBoss = expertBoss;
        bossLibrary.makingMasterBoss = masterBoss;
        bossLibrary.makingAlteringStateBoss = alteringStateBoss;
        bossLibrary.makingExpertAlteringStateBoss = alteringExpertStateBoss;
        bossLibrary.makingMasterAlteringStateBoss = alteringMasterStateBoss;
        // MOVELIBRARY INITIALIZATION
        moveLibrary.makingBossMoveSet = bossMoveSet;
        moveLibrary.makingExpertMoveSet = expertMoveSet;
        moveLibrary.makingMasterMoveSet = masterMoveSet;
        moveLibrary.makingAlteringBossMoveSet = alteringBossMoveSet;
        moveLibrary.makingExpertAlteringBossMoveSet = alteringExpertBossMoveSet;
        moveLibrary.makingMasterAlteringBossMoveSet = alteringMasterBossMoveSet;
        // Displaying the text for each boss
        displayBossInfo = findViewById(R.id.tvDisplayBossInfo);
        // The user input
        bossName = findViewById(R.id.etBossName);
        difficultyCompleted = findViewById(R.id.etDifficulty);
        rating = findViewById(R.id.etRating);
        // Buttons for WIKI
        search = findViewById(R.id.btnSearch);
        normal = findViewById(R.id.btnNormal);
        expert = findViewById(R.id.btnExpert);
        master = findViewById(R.id.btnMaster);
        firstStage = findViewById(R.id.btnFirstStage);
        secondStage = findViewById(R.id.btnSecondForm);
        start = findViewById(R.id.btnStartGame);
        previous = findViewById(R.id.btnPrevious);
        previousE = findViewById(R.id.btnPreviousE);
        previousM = findViewById(R.id.btnPreviousM);
        next = findViewById(R.id.btnNext);
        nextE = findViewById(R.id.btnNextE);
        nextM = findViewById(R.id.btnNextM);
        showAttacks = findViewById(R.id.btnShowAttacks);
        showBossInfo = findViewById(R.id.btnShowInfo);
        //BOSS CHECKLIST FUNCTION |
        libraryOfCheckLists = new CheckList[100];
        // Buttons for BossChecklist
        bossCheckList = findViewById(R.id.btnBossCheckList);
        complete = findViewById(R.id.btnComplete);
        // Text for BossCheckList
        displayCheckList = findViewById(R.id.tvDisplayCheckList);


        //ImageView
        // PRE HARD MODE BOSS IMAGES
        terrariaLogo = findViewById(R.id.imageTerrariaLogo);
        kingSlime = findViewById(R.id.imageKingSlime);
        eyeOfCthulhu = findViewById(R.id.imageEyeOfCthulhu);
        eaterOfWorlds = findViewById(R.id.imageEaterOfWorlds);
        brainOfCthulhu = findViewById(R.id.imageBrainOfCthulhu);
        queenBee = findViewById(R.id.imageQueenBee);
        skeletron = findViewById(R.id.imageSkeletron);
        deerClops = findViewById(R.id.imageDeerClops);
        wallOfFlesh = findViewById(R.id.imageWallOfFlesh);
        // PRE HARD MODE BOSS SECOND STAGE IMAGES
        eyeOfCthuluSS = findViewById(R.id.imageEyeOfCthulhuSS);
        brainOfCthulhuSS = findViewById(R.id.imageBrainOfCthulhuSS);

        // POST HARD MODE/ HARD MODE BOSS IMAGES
        queenSlime = findViewById(R.id.imageQueenSlime);
        theTwins = findViewById(R.id.imageTheTwins);
        theDestroyer = findViewById(R.id.imageTheDestroyer);
        skeletronPrime = findViewById(R.id.imageSkeletronPrime);
        plantera = findViewById(R.id.imagePlantera);
        golem = findViewById(R.id.imageGolem);
        dukeFishron = findViewById(R.id.imageDukeFishron);
        empressOfLight = findViewById(R.id.imageEmpressOfLight);
        lunaticCultist = findViewById(R.id.imageLunaticCultist);
        moonLord = findViewById(R.id.imageMoonLord);

        // POST HARD MODE BOSS SECOND STAGE IMAGES
        queenSlimeSS = findViewById(R.id.imageQueenSlimeSS);
        theTwinsSS = findViewById(R.id.imageTheTwinsSS);
        planteraSS = findViewById(R.id.imagePlanteraSS);
        golemSS = findViewById(R.id.imageGolemSS);
        dukeFishronSS = findViewById(R.id.imageDukeFishronSS);
        empressOfLightSS = findViewById(R.id.imageEmpressOfLightSS);

    }

    private void startToggleUI() {
        start.setVisibility(View.INVISIBLE);
        search.setVisibility(View.VISIBLE);
        normal.setVisibility(View.INVISIBLE);
        expert.setVisibility(View.VISIBLE);
        master.setVisibility(View.VISIBLE);
        secondStage.setVisibility(View.VISIBLE);
        previous.setVisibility(View.VISIBLE);
        next.setVisibility(View.VISIBLE);
        showAttacks.setVisibility(View.VISIBLE);
        bossCheckList.setVisibility(View.VISIBLE);
        bossName.setVisibility(View.VISIBLE);
        terrariaLogo.setVisibility(View.INVISIBLE);


    }

    /**
     * This is just for starting the game and when the button is pressed it displays the first object or the first instance of a boss.
     *
     * @param v
     */
    public void onStartGame(View v) {
        startToggleUI();
        start.setVisibility(View.INVISIBLE);
        bossIndexNumber = 0;
        bossIndexExpert = 0;
        bossIndexMaster = 0;
        displayBossInfo.setText(normalBosses[bossIndexNumber].toString());
        bossImageLogic();
    }

    /**
     * This is the search function where you can look for any boss.
     *
     * @param v
     */
    public void onSearch(View v) {
        searchingThroughBosses();

    }

    public Boss searchingThroughBosses() {
        String foundName = bossName.getText().toString();
        Boss found = null;

          if (normal.getVisibility() == View.INVISIBLE) {
              for (int i = 0; i <= bossLibrary.getStationaryIndexNumber() - 1; i++) {
                  if (normalBosses[i].getName().equalsIgnoreCase(foundName.toUpperCase())) {
                      found = normalBosses[i];
                      bossIndexNumber = i;
                      displayBossInfo.setText(normalBosses[i].toString());
                      break;
                  }
              }

          }


        if (expert.getVisibility() == View.INVISIBLE) {
            for (int i = 0; i <= bossLibrary.getStationaryIndexNumber() - 1; i++) {
                if (expertBoss[i].getName().equalsIgnoreCase(foundName.toUpperCase())) {
                    found = expertBoss[i];
                    bossIndexNumber = i;
                    displayBossInfo.setText(expertBoss[i].toString());
                    break;
                }
            }
        }
        if (master.getVisibility() == View.INVISIBLE) {
            for (int i = 0; i <= bossLibrary.getStationaryIndexNumber() - 1; i++) {
                if (masterBoss[i].getName().equalsIgnoreCase(foundName)) {
                    found = masterBoss[i];
                    bossIndexNumber = i;
                    displayBossInfo.setText(masterBoss[i].toString());
                    break;
                }
            }
        }
        bossName.setText("");
        bossImageLogic();
        return found;

    }


    /**
     * All three of these norma,expert and master will be the difficulty that the player can choose to look
     * at there information.
     *
     * @param v
     */
    public void normalMode(View v) {
        normal.setVisibility(View.INVISIBLE);
        expert.setVisibility(View.VISIBLE);
        master.setVisibility(View.VISIBLE);
        if (showAttacks.getVisibility() == View.VISIBLE) {
            for (int i = 0; i < normalBosses.length; i++) {
                if (i == bossIndexNumber) {
                    displayBossInfo.setText(normalBosses[i].toString());
                    togglePreviousAndNextBtn();
                    break;
                }

            }
        }
        if (showBossInfo.getVisibility() == View.VISIBLE) {
            pickingBossMoves();
        }
        if (firstStage.getVisibility() == View.VISIBLE) {
            pickingSecondStageMoves();
        }
    }

    public void expertMode(View v) {
        normal.setVisibility(View.VISIBLE);
        expert.setVisibility(View.INVISIBLE);
        master.setVisibility(View.VISIBLE);
        if (showAttacks.getVisibility() == View.VISIBLE) {
            for (int i = 0; i < expertBoss.length; i++) {
                if (i == bossIndexNumber) {
                    displayBossInfo.setText(expertBoss[i].toString());
                    togglePreviousAndNextBtn();
                    break;

                }
            }
        }

        if (showBossInfo.getVisibility() == View.VISIBLE) {
            pickingBossMoves();
        }
        if (firstStage.getVisibility() == View.VISIBLE) {
            pickingSecondStageMoves();
        }
    }

    public void masterMode(View v) {
        normal.setVisibility(View.VISIBLE);
        expert.setVisibility(View.VISIBLE);
        master.setVisibility(View.INVISIBLE);
        if (showAttacks.getVisibility() == View.VISIBLE) {
            for (int i = 0; i < masterBoss.length; i++) {
                if (i == bossIndexNumber) {
                    displayBossInfo.setText(masterBoss[i].toString());
                    togglePreviousAndNextBtn();
                    break;
                }
            }
        }
        if (showBossInfo.getVisibility() == View.VISIBLE) {
            pickingBossMoves();
        }
        if (firstStage.getVisibility() == View.VISIBLE) {
            pickingSecondStageMoves();
        }

    }

    // Extra information dicatating if the boss is on his second form
    public void secondStage(View v) {
        showAttacks.setVisibility(View.INVISIBLE);
        previous.setVisibility(View.INVISIBLE);
        next.setVisibility(View.INVISIBLE);
        search.setVisibility(View.INVISIBLE);
        bossCheckList.setVisibility(View.INVISIBLE);
        bossName.setEnabled(false);
        pickingSecondStageMoves();
        secondStage.setVisibility(View.INVISIBLE);
        firstStage.setVisibility(View.VISIBLE);

    }

    public void firstStage(View v) {
        showAttacks.setVisibility(View.VISIBLE);
        search.setVisibility(View.VISIBLE);
        bossCheckList.setVisibility(View.VISIBLE);
        bossName.setEnabled(true);
        if (normal.getVisibility() == View.INVISIBLE) {
            for (int i = 0; i < normalBosses.length; i++) {
                if (i == bossIndexNumber) {
                    displayBossInfo.setText(normalBosses[i].toString());
                    firstStage.setVisibility(View.INVISIBLE);
                    secondStage.setVisibility(View.VISIBLE);
                }
            }
        }

        if (expert.getVisibility() == View.INVISIBLE) {
            for (int i = 0; i < normalBosses.length; i++) {
                if (i == bossIndexNumber) {
                    displayBossInfo.setText(expertBoss[i].toString());
                    firstStage.setVisibility(View.INVISIBLE);
                    secondStage.setVisibility(View.VISIBLE);
                }
            }
        }
        if (master.getVisibility() == View.INVISIBLE) {
            for (int i = 0; i < normalBosses.length; i++) {
                if (i == bossIndexNumber) {
                    displayBossInfo.setText(masterBoss[i].toString());
                    firstStage.setVisibility(View.INVISIBLE);
                    secondStage.setVisibility(View.VISIBLE);
                }
            }
        }
        bossImageLogic();
        secondStageBossImageLogic();
        togglePreviousAndNextBtn();
    }

    //Going forward
    public void nextButton(View v) {

            if (bossIndexNumber >= bossLibrary.getStationaryIndexNumber() - 1) {
                bossIndexNumber = 0;
                displayBossInfo.setText(normalBosses[bossIndexNumber].toString());
                displayCheckList.setVisibility(View.INVISIBLE);
                bossImageLogic();
                return;

            } else {
                bossIndexNumber++;
                displayBossInfo.setText(normalBosses[bossIndexNumber].toString());
                displayCheckList.setVisibility(View.INVISIBLE);
                movingIndexNumber++;
            }
        bossImageLogic();
    }

    public void nextExpertButton(View v) {
        if (bossIndexNumber >= bossLibrary.getStationaryIndexNumber() - 1) {
            bossIndexNumber = 0;
            displayBossInfo.setText(expertBoss[bossIndexNumber].toString());
            bossImageLogic();
            return;

        } else {
            bossIndexNumber++;
            displayBossInfo.setText(expertBoss[bossIndexNumber].toString());
            movingIndexNumber++;

        }

        bossImageLogic();
    }

    public void nextMasterButton(View v) {
        if (bossIndexNumber >= bossLibrary.getStationaryIndexNumber() - 1) {
            bossIndexNumber = 0;
            displayBossInfo.setText(masterBoss[bossIndexNumber].toString());
            bossImageLogic();
            return;

        } else {
            bossIndexNumber++;
            displayBossInfo.setText(masterBoss[bossIndexNumber].toString());
            movingIndexNumber++;

        }

        bossImageLogic();
    }

    //Going back
    public void previousButton(View v) {
        if (bossIndexNumber <= 0) {
            bossIndexNumber = bossLibrary.getStationaryIndexNumber() - 1;
            displayBossInfo.setText(normalBosses[bossIndexNumber].toString());
            bossImageLogic();
        } else {
            movingIndexNumber--;
            displayBossInfo.setText(normalBosses[--bossIndexNumber].toString());
            bossImageLogic();
        }
    }

    public void previousExpertButton(View v) {
        if (bossIndexNumber <= 0) {
            bossIndexNumber = bossLibrary.getStationaryIndexNumber() - 1;
            displayBossInfo.setText(expertBoss[bossIndexNumber].toString());
            bossImageLogic();
        } else {
            movingIndexNumber--;
            displayBossInfo.setText(expertBoss[--bossIndexNumber].toString());
            bossImageLogic();
        }
    }

    public void previousMasterButton(View v) {
        if (bossIndexNumber <= 0) {
            bossIndexNumber = bossLibrary.getStationaryIndexNumber() - 1;
            displayBossInfo.setText(masterBoss[bossIndexNumber].toString());
            bossImageLogic();
        } else {
            movingIndexNumber--;
            displayBossInfo.setText(masterBoss[--bossIndexNumber].toString());
            bossImageLogic();
        }
    }

    public void bossAttacks(View v) {
        pickingBossMoves();
        showBossInfo.setVisibility(View.VISIBLE);
        showAttacks.setVisibility(View.INVISIBLE);
        previous.setVisibility(View.INVISIBLE);
        previousE.setVisibility(View.INVISIBLE);
        previousM.setVisibility(View.INVISIBLE);
        next.setVisibility(View.INVISIBLE);
        nextE.setVisibility(View.INVISIBLE);
        nextM.setVisibility(View.INVISIBLE);
        search.setVisibility(View.INVISIBLE);
        secondStage.setVisibility(View.INVISIBLE);
        bossCheckList.setVisibility(View.INVISIBLE);
        bossName.setEnabled(false);
    }

    public void showBossInfo(View v) {
        bossCheckList.setVisibility(View.VISIBLE);
        showAttacks.setVisibility(View.VISIBLE);
        showBossInfo.setVisibility(View.INVISIBLE);
        previous.setVisibility(View.VISIBLE);
        next.setVisibility(View.VISIBLE);
        search.setVisibility(View.VISIBLE);
        secondStage.setVisibility(View.VISIBLE);
        difficultyCompleted.setVisibility(View.INVISIBLE);
        rating.setVisibility(View.INVISIBLE);
        complete.setVisibility(View.INVISIBLE);
        bossName.setVisibility(View.VISIBLE);
        bossName.setEnabled(true);
        displayCheckList.setVisibility(View.INVISIBLE);

        if (normal.getVisibility() == View.INVISIBLE) {
            for (int i = 0; i < normalBosses.length; i++) {
                if (i == bossIndexNumber) {
                    displayBossInfo.setText(normalBosses[i].toString());
                    normal.setVisibility(View.INVISIBLE);
                    expert.setVisibility(View.VISIBLE);
                    master.setVisibility(View.VISIBLE);
                }
            }
        }
        if (expert.getVisibility() == View.INVISIBLE) {
            for (int i = 0; i < normalBosses.length; i++) {
                if (i == bossIndexNumber) {
                    displayBossInfo.setText(expertBoss[i].toString());
                    expert.setVisibility(View.INVISIBLE);
                }
            }
        }
        if (master.getVisibility() == View.INVISIBLE) {
            for (int i = 0; i < normalBosses.length; i++) {
                if (i == bossIndexNumber) {
                    displayBossInfo.setText(masterBoss[i].toString());
                    master.setVisibility(View.INVISIBLE);
                }
            }
        }
        togglePreviousAndNextBtn();
    }

    public void onBossChecklist(View v) {
        updateUIForCheckList();
        bossImageLogic();
        StringBuilder checkListString = new StringBuilder();
        displayCheckList.setVisibility(View.VISIBLE);
        displayBossInfo.setText(checkListString.append(normalBosses[bossIndexNumber].getName()).append(": Boss checklist\n\n").append("Difficutly completed: \n\n\n\n").append("Boss rating:").toString());
    }
    public void addingNewChecklist(CheckList newChecklist){
        if (checkListCount < libraryOfCheckLists.length){
            libraryOfCheckLists[++checkListCount] = newChecklist;
        }
    }


    public void onCompleteChecklist(View v) {
        String stringDifficulty = difficultyCompleted.getText().toString();
        String stringRating = rating.getText().toString();
            try {
                int intRating = Integer.parseInt(stringRating);
                CheckList bossCheck = new CheckList(stringDifficulty, intRating);
                addingNewChecklist(bossCheck);
                displayList(libraryOfCheckLists);
                showBossInfo.setVisibility(View.VISIBLE);
                displayCheckList.setVisibility(View.VISIBLE);
                difficultyCompleted.setText("");
                rating.setText("");
            } catch (InvalidDifficultyException wrongDifficulty) {
                difficultyCompleted.setError("Difficulty invalid. Must be either Normal, Expert, or Master");
            } catch (InvalidRatingException wrongRating) {
                rating.setError("Rating is not between 1 - 10");
            } catch (NumberFormatException inputNumbers){
                rating.setError("There has to be a number here. Between 1-10");
            }

    }

        private void displayList(CheckList[] checkList) {
            String objectText = normalBosses[bossIndexNumber].getName() + ":" + "\n";
            for (Object item : checkList) {
                if (item != null) {
                    objectText += item + "\n";
                }
            }
            displayCheckList.setText(objectText);
        }



    public void bossImageLogic() {
        if (bossIndexNumber == -1) {
            kingSlime.setVisibility(View.INVISIBLE);
            eyeOfCthulhu.setVisibility(View.INVISIBLE);
            eaterOfWorlds.setVisibility(View.INVISIBLE);
            brainOfCthulhu.setVisibility(View.INVISIBLE);
            queenBee.setVisibility(View.INVISIBLE);
            skeletron.setVisibility(View.INVISIBLE);
            deerClops.setVisibility(View.INVISIBLE);
            wallOfFlesh.setVisibility(View.INVISIBLE);
            queenSlime.setVisibility(View.INVISIBLE);
            theTwins.setVisibility(View.INVISIBLE);
            theDestroyer.setVisibility(View.INVISIBLE);
            skeletronPrime.setVisibility(View.INVISIBLE);
            plantera.setVisibility(View.INVISIBLE);
            golem.setVisibility(View.INVISIBLE);
            dukeFishron.setVisibility(View.INVISIBLE);
            empressOfLight.setVisibility(View.INVISIBLE);
            lunaticCultist.setVisibility(View.INVISIBLE);
            moonLord.setVisibility(View.INVISIBLE);
            return;
        }
        if (bossIndexNumber == 0 || bossIndexExpert == 0 || bossIndexMaster == 0) {
            kingSlime.setVisibility(View.VISIBLE);
            eyeOfCthulhu.setVisibility(View.INVISIBLE);
            eaterOfWorlds.setVisibility(View.INVISIBLE);
            brainOfCthulhu.setVisibility(View.INVISIBLE);
            queenBee.setVisibility(View.INVISIBLE);
            skeletron.setVisibility(View.INVISIBLE);
            deerClops.setVisibility(View.INVISIBLE);
            wallOfFlesh.setVisibility(View.INVISIBLE);
            queenSlime.setVisibility(View.INVISIBLE);
            theTwins.setVisibility(View.INVISIBLE);
            theDestroyer.setVisibility(View.INVISIBLE);
            skeletronPrime.setVisibility(View.INVISIBLE);
            plantera.setVisibility(View.INVISIBLE);
            golem.setVisibility(View.INVISIBLE);
            dukeFishron.setVisibility(View.INVISIBLE);
            empressOfLight.setVisibility(View.INVISIBLE);
            lunaticCultist.setVisibility(View.INVISIBLE);
            moonLord.setVisibility(View.INVISIBLE);
        }
        if (bossIndexNumber == 1 || bossIndexExpert == 1 || bossIndexMaster == 1) {
            kingSlime.setVisibility(View.INVISIBLE);
            eyeOfCthulhu.setVisibility(View.VISIBLE);
            eaterOfWorlds.setVisibility(View.INVISIBLE);
            brainOfCthulhu.setVisibility(View.INVISIBLE);
            queenBee.setVisibility(View.INVISIBLE);
            skeletron.setVisibility(View.INVISIBLE);
            deerClops.setVisibility(View.INVISIBLE);
            wallOfFlesh.setVisibility(View.INVISIBLE);
            queenSlime.setVisibility(View.INVISIBLE);
            theTwins.setVisibility(View.INVISIBLE);
            theDestroyer.setVisibility(View.INVISIBLE);
            skeletronPrime.setVisibility(View.INVISIBLE);
            plantera.setVisibility(View.INVISIBLE);
            golem.setVisibility(View.INVISIBLE);
            dukeFishron.setVisibility(View.INVISIBLE);
            empressOfLight.setVisibility(View.INVISIBLE);
            lunaticCultist.setVisibility(View.INVISIBLE);
            moonLord.setVisibility(View.INVISIBLE);
        }
        if (bossIndexNumber == 2 || bossIndexExpert == 2 || bossIndexMaster == 2) {
            kingSlime.setVisibility(View.INVISIBLE);
            eyeOfCthulhu.setVisibility(View.INVISIBLE);
            eaterOfWorlds.setVisibility(View.VISIBLE);
            brainOfCthulhu.setVisibility(View.INVISIBLE);
            queenBee.setVisibility(View.INVISIBLE);
            skeletron.setVisibility(View.INVISIBLE);
            deerClops.setVisibility(View.INVISIBLE);
            wallOfFlesh.setVisibility(View.INVISIBLE);
            queenSlime.setVisibility(View.INVISIBLE);
            theTwins.setVisibility(View.INVISIBLE);
            theDestroyer.setVisibility(View.INVISIBLE);
            skeletronPrime.setVisibility(View.INVISIBLE);
            plantera.setVisibility(View.INVISIBLE);
            golem.setVisibility(View.INVISIBLE);
            dukeFishron.setVisibility(View.INVISIBLE);
            empressOfLight.setVisibility(View.INVISIBLE);
            lunaticCultist.setVisibility(View.INVISIBLE);
            moonLord.setVisibility(View.INVISIBLE);

        }
        if (bossIndexNumber == 3 || bossIndexExpert == 3 || bossIndexMaster == 3) {
            kingSlime.setVisibility(View.INVISIBLE);
            eyeOfCthulhu.setVisibility(View.INVISIBLE);
            eaterOfWorlds.setVisibility(View.INVISIBLE);
            brainOfCthulhu.setVisibility(View.VISIBLE);
            queenBee.setVisibility(View.INVISIBLE);
            skeletron.setVisibility(View.INVISIBLE);
            deerClops.setVisibility(View.INVISIBLE);
            wallOfFlesh.setVisibility(View.INVISIBLE);
            queenSlime.setVisibility(View.INVISIBLE);
            theTwins.setVisibility(View.INVISIBLE);
            theDestroyer.setVisibility(View.INVISIBLE);
            skeletronPrime.setVisibility(View.INVISIBLE);
            plantera.setVisibility(View.INVISIBLE);
            golem.setVisibility(View.INVISIBLE);
            dukeFishron.setVisibility(View.INVISIBLE);
            empressOfLight.setVisibility(View.INVISIBLE);
            lunaticCultist.setVisibility(View.INVISIBLE);
            moonLord.setVisibility(View.INVISIBLE);
        }
        if (bossIndexNumber == 4 || bossIndexExpert == 4 || bossIndexMaster == 4) {
            kingSlime.setVisibility(View.INVISIBLE);
            eyeOfCthulhu.setVisibility(View.INVISIBLE);
            eaterOfWorlds.setVisibility(View.INVISIBLE);
            brainOfCthulhu.setVisibility(View.INVISIBLE);
            queenBee.setVisibility(View.VISIBLE);
            skeletron.setVisibility(View.INVISIBLE);
            deerClops.setVisibility(View.INVISIBLE);
            wallOfFlesh.setVisibility(View.INVISIBLE);
            queenSlime.setVisibility(View.INVISIBLE);
            theTwins.setVisibility(View.INVISIBLE);
            theDestroyer.setVisibility(View.INVISIBLE);
            skeletronPrime.setVisibility(View.INVISIBLE);
            plantera.setVisibility(View.INVISIBLE);
            golem.setVisibility(View.INVISIBLE);
            dukeFishron.setVisibility(View.INVISIBLE);
            empressOfLight.setVisibility(View.INVISIBLE);
            lunaticCultist.setVisibility(View.INVISIBLE);
            moonLord.setVisibility(View.INVISIBLE);
        }
        if (bossIndexNumber == 5 || bossIndexExpert == 5 || bossIndexMaster == 5) {
            kingSlime.setVisibility(View.INVISIBLE);
            eyeOfCthulhu.setVisibility(View.INVISIBLE);
            eaterOfWorlds.setVisibility(View.INVISIBLE);
            brainOfCthulhu.setVisibility(View.INVISIBLE);
            queenBee.setVisibility(View.INVISIBLE);
            skeletron.setVisibility(View.VISIBLE);
            deerClops.setVisibility(View.INVISIBLE);
            wallOfFlesh.setVisibility(View.INVISIBLE);
            queenSlime.setVisibility(View.INVISIBLE);
            theTwins.setVisibility(View.INVISIBLE);
            theDestroyer.setVisibility(View.INVISIBLE);
            skeletronPrime.setVisibility(View.INVISIBLE);
            plantera.setVisibility(View.INVISIBLE);
            golem.setVisibility(View.INVISIBLE);
            dukeFishron.setVisibility(View.INVISIBLE);
            empressOfLight.setVisibility(View.INVISIBLE);
            lunaticCultist.setVisibility(View.INVISIBLE);
            moonLord.setVisibility(View.INVISIBLE);
        }
        if (bossIndexNumber == 6 || bossIndexExpert == 6 || bossIndexMaster == 6) {
            kingSlime.setVisibility(View.INVISIBLE);
            eyeOfCthulhu.setVisibility(View.INVISIBLE);
            eaterOfWorlds.setVisibility(View.INVISIBLE);
            brainOfCthulhu.setVisibility(View.INVISIBLE);
            queenBee.setVisibility(View.INVISIBLE);
            skeletron.setVisibility(View.INVISIBLE);
            deerClops.setVisibility(View.VISIBLE);
            wallOfFlesh.setVisibility(View.INVISIBLE);
            queenSlime.setVisibility(View.INVISIBLE);
            theTwins.setVisibility(View.INVISIBLE);
            theDestroyer.setVisibility(View.INVISIBLE);
            skeletronPrime.setVisibility(View.INVISIBLE);
            plantera.setVisibility(View.INVISIBLE);
            golem.setVisibility(View.INVISIBLE);
            dukeFishron.setVisibility(View.INVISIBLE);
            empressOfLight.setVisibility(View.INVISIBLE);
            lunaticCultist.setVisibility(View.INVISIBLE);
            moonLord.setVisibility(View.INVISIBLE);
        }
        if (bossIndexNumber == 7 || bossIndexExpert == 7 || bossIndexMaster == 7) {
            kingSlime.setVisibility(View.INVISIBLE);
            eyeOfCthulhu.setVisibility(View.INVISIBLE);
            eaterOfWorlds.setVisibility(View.INVISIBLE);
            brainOfCthulhu.setVisibility(View.INVISIBLE);
            queenBee.setVisibility(View.INVISIBLE);
            skeletron.setVisibility(View.INVISIBLE);
            deerClops.setVisibility(View.INVISIBLE);
            wallOfFlesh.setVisibility(View.VISIBLE);
            queenSlime.setVisibility(View.INVISIBLE);
            theTwins.setVisibility(View.INVISIBLE);
            theDestroyer.setVisibility(View.INVISIBLE);
            skeletronPrime.setVisibility(View.INVISIBLE);
            plantera.setVisibility(View.INVISIBLE);
            golem.setVisibility(View.INVISIBLE);
            dukeFishron.setVisibility(View.INVISIBLE);
            empressOfLight.setVisibility(View.INVISIBLE);
            lunaticCultist.setVisibility(View.INVISIBLE);
            moonLord.setVisibility(View.INVISIBLE);
        }
        if (bossIndexNumber == 8 || bossIndexExpert == 8 || bossIndexMaster == 8) {
            kingSlime.setVisibility(View.INVISIBLE);
            eyeOfCthulhu.setVisibility(View.INVISIBLE);
            eaterOfWorlds.setVisibility(View.INVISIBLE);
            brainOfCthulhu.setVisibility(View.INVISIBLE);
            queenBee.setVisibility(View.INVISIBLE);
            skeletron.setVisibility(View.INVISIBLE);
            deerClops.setVisibility(View.INVISIBLE);
            wallOfFlesh.setVisibility(View.INVISIBLE);
            queenSlime.setVisibility(View.VISIBLE);
            theTwins.setVisibility(View.INVISIBLE);
            theDestroyer.setVisibility(View.INVISIBLE);
            skeletronPrime.setVisibility(View.INVISIBLE);
            plantera.setVisibility(View.INVISIBLE);
            golem.setVisibility(View.INVISIBLE);
            dukeFishron.setVisibility(View.INVISIBLE);
            empressOfLight.setVisibility(View.INVISIBLE);
            lunaticCultist.setVisibility(View.INVISIBLE);
            moonLord.setVisibility(View.INVISIBLE);
        }
        if (bossIndexNumber == 9 || bossIndexExpert == 9 || bossIndexMaster == 9) {
            kingSlime.setVisibility(View.INVISIBLE);
            eyeOfCthulhu.setVisibility(View.INVISIBLE);
            eaterOfWorlds.setVisibility(View.INVISIBLE);
            brainOfCthulhu.setVisibility(View.INVISIBLE);
            queenBee.setVisibility(View.INVISIBLE);
            skeletron.setVisibility(View.INVISIBLE);
            deerClops.setVisibility(View.INVISIBLE);
            wallOfFlesh.setVisibility(View.INVISIBLE);
            queenSlime.setVisibility(View.INVISIBLE);
            theTwins.setVisibility(View.VISIBLE);
            theDestroyer.setVisibility(View.INVISIBLE);
            skeletronPrime.setVisibility(View.INVISIBLE);
            plantera.setVisibility(View.INVISIBLE);
            golem.setVisibility(View.INVISIBLE);
            dukeFishron.setVisibility(View.INVISIBLE);
            empressOfLight.setVisibility(View.INVISIBLE);
            lunaticCultist.setVisibility(View.INVISIBLE);
            moonLord.setVisibility(View.INVISIBLE);
        }
        if (bossIndexNumber == 10 || bossIndexExpert == 10 || bossIndexMaster == 10) {
            kingSlime.setVisibility(View.INVISIBLE);
            eyeOfCthulhu.setVisibility(View.INVISIBLE);
            eaterOfWorlds.setVisibility(View.INVISIBLE);
            brainOfCthulhu.setVisibility(View.INVISIBLE);
            queenBee.setVisibility(View.INVISIBLE);
            skeletron.setVisibility(View.INVISIBLE);
            deerClops.setVisibility(View.INVISIBLE);
            wallOfFlesh.setVisibility(View.INVISIBLE);
            queenSlime.setVisibility(View.INVISIBLE);
            theTwins.setVisibility(View.INVISIBLE);
            theDestroyer.setVisibility(View.VISIBLE);
            skeletronPrime.setVisibility(View.INVISIBLE);
            plantera.setVisibility(View.INVISIBLE);
            golem.setVisibility(View.INVISIBLE);
            dukeFishron.setVisibility(View.INVISIBLE);
            empressOfLight.setVisibility(View.INVISIBLE);
            lunaticCultist.setVisibility(View.INVISIBLE);
            moonLord.setVisibility(View.INVISIBLE);
        }
        if (bossIndexNumber == 11 || bossIndexExpert == 11 || bossIndexMaster == 11) {
            kingSlime.setVisibility(View.INVISIBLE);
            eyeOfCthulhu.setVisibility(View.INVISIBLE);
            eaterOfWorlds.setVisibility(View.INVISIBLE);
            brainOfCthulhu.setVisibility(View.INVISIBLE);
            queenBee.setVisibility(View.INVISIBLE);
            skeletron.setVisibility(View.INVISIBLE);
            deerClops.setVisibility(View.INVISIBLE);
            wallOfFlesh.setVisibility(View.INVISIBLE);
            queenSlime.setVisibility(View.INVISIBLE);
            theTwins.setVisibility(View.INVISIBLE);
            theDestroyer.setVisibility(View.INVISIBLE);
            skeletronPrime.setVisibility(View.VISIBLE);
            plantera.setVisibility(View.INVISIBLE);
            golem.setVisibility(View.INVISIBLE);
            dukeFishron.setVisibility(View.INVISIBLE);
            empressOfLight.setVisibility(View.INVISIBLE);
            lunaticCultist.setVisibility(View.INVISIBLE);
            moonLord.setVisibility(View.INVISIBLE);
        }
        if (bossIndexNumber == 12 || bossIndexExpert == 12 || bossIndexMaster == 12) {
            kingSlime.setVisibility(View.INVISIBLE);
            eyeOfCthulhu.setVisibility(View.INVISIBLE);
            eaterOfWorlds.setVisibility(View.INVISIBLE);
            brainOfCthulhu.setVisibility(View.INVISIBLE);
            queenBee.setVisibility(View.INVISIBLE);
            skeletron.setVisibility(View.INVISIBLE);
            deerClops.setVisibility(View.INVISIBLE);
            wallOfFlesh.setVisibility(View.INVISIBLE);
            queenSlime.setVisibility(View.INVISIBLE);
            theTwins.setVisibility(View.INVISIBLE);
            theDestroyer.setVisibility(View.INVISIBLE);
            skeletronPrime.setVisibility(View.INVISIBLE);
            plantera.setVisibility(View.VISIBLE);
            golem.setVisibility(View.INVISIBLE);
            dukeFishron.setVisibility(View.INVISIBLE);
            empressOfLight.setVisibility(View.INVISIBLE);
            lunaticCultist.setVisibility(View.INVISIBLE);
            moonLord.setVisibility(View.INVISIBLE);
        }
        if (bossIndexNumber == 13 || bossIndexExpert == 13 || bossIndexMaster == 13) {
            kingSlime.setVisibility(View.INVISIBLE);
            eyeOfCthulhu.setVisibility(View.INVISIBLE);
            eaterOfWorlds.setVisibility(View.INVISIBLE);
            brainOfCthulhu.setVisibility(View.INVISIBLE);
            queenBee.setVisibility(View.INVISIBLE);
            skeletron.setVisibility(View.INVISIBLE);
            deerClops.setVisibility(View.INVISIBLE);
            wallOfFlesh.setVisibility(View.INVISIBLE);
            queenSlime.setVisibility(View.INVISIBLE);
            theTwins.setVisibility(View.INVISIBLE);
            theDestroyer.setVisibility(View.INVISIBLE);
            skeletronPrime.setVisibility(View.INVISIBLE);
            plantera.setVisibility(View.INVISIBLE);
            golem.setVisibility(View.VISIBLE);
            dukeFishron.setVisibility(View.INVISIBLE);
            empressOfLight.setVisibility(View.INVISIBLE);
            lunaticCultist.setVisibility(View.INVISIBLE);
            moonLord.setVisibility(View.INVISIBLE);
        }
        if (bossIndexNumber == 14 || bossIndexExpert == 14 || bossIndexMaster == 14) {
            kingSlime.setVisibility(View.INVISIBLE);
            eyeOfCthulhu.setVisibility(View.INVISIBLE);
            eaterOfWorlds.setVisibility(View.INVISIBLE);
            brainOfCthulhu.setVisibility(View.INVISIBLE);
            queenBee.setVisibility(View.INVISIBLE);
            skeletron.setVisibility(View.INVISIBLE);
            deerClops.setVisibility(View.INVISIBLE);
            wallOfFlesh.setVisibility(View.INVISIBLE);
            queenSlime.setVisibility(View.INVISIBLE);
            theTwins.setVisibility(View.INVISIBLE);
            theDestroyer.setVisibility(View.INVISIBLE);
            skeletronPrime.setVisibility(View.INVISIBLE);
            plantera.setVisibility(View.INVISIBLE);
            golem.setVisibility(View.INVISIBLE);
            dukeFishron.setVisibility(View.VISIBLE);
            empressOfLight.setVisibility(View.INVISIBLE);
            lunaticCultist.setVisibility(View.INVISIBLE);
            moonLord.setVisibility(View.INVISIBLE);
        }
        if (bossIndexNumber == 15 || bossIndexExpert == 15 || bossIndexMaster == 15) {
            kingSlime.setVisibility(View.INVISIBLE);
            eyeOfCthulhu.setVisibility(View.INVISIBLE);
            eaterOfWorlds.setVisibility(View.INVISIBLE);
            brainOfCthulhu.setVisibility(View.INVISIBLE);
            queenBee.setVisibility(View.INVISIBLE);
            skeletron.setVisibility(View.INVISIBLE);
            deerClops.setVisibility(View.INVISIBLE);
            wallOfFlesh.setVisibility(View.INVISIBLE);
            queenSlime.setVisibility(View.INVISIBLE);
            theTwins.setVisibility(View.INVISIBLE);
            theDestroyer.setVisibility(View.INVISIBLE);
            skeletronPrime.setVisibility(View.INVISIBLE);
            plantera.setVisibility(View.INVISIBLE);
            golem.setVisibility(View.INVISIBLE);
            dukeFishron.setVisibility(View.INVISIBLE);
            empressOfLight.setVisibility(View.VISIBLE);
            lunaticCultist.setVisibility(View.INVISIBLE);
            moonLord.setVisibility(View.INVISIBLE);
        }
        if (bossIndexNumber == 16 || bossIndexExpert == 16 || bossIndexMaster == 16) {
            kingSlime.setVisibility(View.INVISIBLE);
            eyeOfCthulhu.setVisibility(View.INVISIBLE);
            eaterOfWorlds.setVisibility(View.INVISIBLE);
            brainOfCthulhu.setVisibility(View.INVISIBLE);
            queenBee.setVisibility(View.INVISIBLE);
            skeletron.setVisibility(View.INVISIBLE);
            deerClops.setVisibility(View.INVISIBLE);
            wallOfFlesh.setVisibility(View.INVISIBLE);
            queenSlime.setVisibility(View.INVISIBLE);
            theTwins.setVisibility(View.INVISIBLE);
            theDestroyer.setVisibility(View.INVISIBLE);
            skeletronPrime.setVisibility(View.INVISIBLE);
            plantera.setVisibility(View.INVISIBLE);
            golem.setVisibility(View.INVISIBLE);
            dukeFishron.setVisibility(View.INVISIBLE);
            empressOfLight.setVisibility(View.INVISIBLE);
            lunaticCultist.setVisibility(View.VISIBLE);
            moonLord.setVisibility(View.INVISIBLE);
        }
        if (bossIndexNumber == 17 || bossIndexExpert == 17 || bossIndexMaster == 17) {
            kingSlime.setVisibility(View.INVISIBLE);
            eyeOfCthulhu.setVisibility(View.INVISIBLE);
            eaterOfWorlds.setVisibility(View.INVISIBLE);
            brainOfCthulhu.setVisibility(View.INVISIBLE);
            queenBee.setVisibility(View.INVISIBLE);
            skeletron.setVisibility(View.INVISIBLE);
            deerClops.setVisibility(View.INVISIBLE);
            wallOfFlesh.setVisibility(View.INVISIBLE);
            queenSlime.setVisibility(View.INVISIBLE);
            theTwins.setVisibility(View.INVISIBLE);
            theDestroyer.setVisibility(View.INVISIBLE);
            skeletronPrime.setVisibility(View.INVISIBLE);
            plantera.setVisibility(View.INVISIBLE);
            golem.setVisibility(View.INVISIBLE);
            dukeFishron.setVisibility(View.INVISIBLE);
            empressOfLight.setVisibility(View.INVISIBLE);
            lunaticCultist.setVisibility(View.INVISIBLE);
            moonLord.setVisibility(View.VISIBLE);
        }
    }

    public void secondStageBossImageLogic() {
        if (bossIndexNumber == 1) {
            eyeOfCthuluSS.setVisibility(View.INVISIBLE);
        }
        if (bossIndexNumber == 3) {
            brainOfCthulhuSS.setVisibility(View.INVISIBLE);
        }
        if (bossIndexNumber == 8) {
            queenSlimeSS.setVisibility(View.INVISIBLE);
        }
        if (bossIndexNumber == 9) {
            theTwinsSS.setVisibility(View.INVISIBLE);
        }
        if (bossIndexNumber == 12) {
            planteraSS.setVisibility(View.INVISIBLE);
        }
        if (bossIndexNumber == 13) {
            golemSS.setVisibility(View.INVISIBLE);
        }
        if (bossIndexNumber == 14) {
            dukeFishronSS.setVisibility(View.INVISIBLE);
        }
        if (bossIndexNumber == 15) {
            empressOfLightSS.setVisibility(View.INVISIBLE);
        }
    }

    public void togglePreviousAndNextBtn() {
        if (normal.getVisibility() == View.INVISIBLE) {
            next.setVisibility(View.VISIBLE);
            previous.setVisibility(View.VISIBLE);
            nextE.setVisibility(View.INVISIBLE);
            nextM.setVisibility(View.INVISIBLE);
            previousE.setVisibility(View.INVISIBLE);
            previousM.setVisibility(View.INVISIBLE);
            return;
        }
        if (expert.getVisibility() == View.INVISIBLE) {
            nextE.setVisibility(View.VISIBLE);
            previousE.setVisibility(View.VISIBLE);
            next.setVisibility(View.INVISIBLE);
            nextM.setVisibility(View.INVISIBLE);
            previous.setVisibility(View.INVISIBLE);
            previousM.setVisibility(View.INVISIBLE);
            return;
        }
        if (master.getVisibility() == View.INVISIBLE) {
            nextM.setVisibility(View.VISIBLE);
            previousM.setVisibility(View.VISIBLE);
            next.setVisibility(View.INVISIBLE);
            nextE.setVisibility(View.INVISIBLE);
            previous.setVisibility(View.INVISIBLE);
            previousE.setVisibility(View.INVISIBLE);

        }
    }

    public void updateUIForCheckList() {
        previous.setVisibility(View.INVISIBLE);
        previousE.setVisibility(View.INVISIBLE);
        previousM.setVisibility(View.INVISIBLE);
        next.setVisibility(View.INVISIBLE);
        nextE.setVisibility(View.INVISIBLE);
        nextM.setVisibility(View.INVISIBLE);
        bossName.setVisibility(View.INVISIBLE);
        search.setVisibility(View.INVISIBLE);
        normal.setVisibility(View.INVISIBLE);
        expert.setVisibility(View.INVISIBLE);
        master.setVisibility(View.INVISIBLE);
        secondStage.setVisibility(View.INVISIBLE);
        showAttacks.setVisibility(View.INVISIBLE);
        difficultyCompleted.setVisibility(View.VISIBLE);
        rating.setVisibility(View.VISIBLE);
        complete.setVisibility(View.VISIBLE);
        bossCheckList.setVisibility(View.VISIBLE);
    }

    public void pickingBossMoves() {
        if (normal.getVisibility() == View.INVISIBLE) {
            moveLibrary.creatingMoves();
            for (int i = 0; i < normalBosses.length; i++) {
                if (i == bossIndexNumber) {
                    displayBossInfo.setText(bossMoveSet[i].toString());
                }
            }

        }
        if (expert.getVisibility() == View.INVISIBLE) {
            moveLibrary.creatingMoves();
            for (int i = 0; i < expertBoss.length; i++) {
                if (i == bossIndexNumber) {
                    displayBossInfo.setText(expertMoveSet[i].toString());
                }
            }

        }
        if (master.getVisibility() == View.INVISIBLE) {
            moveLibrary.creatingMoves();
            for (int i = 0; i < masterBoss.length; i++) {
                if (i == bossIndexNumber) {
                    displayBossInfo.setText(masterMoveSet[i].toString());
                }
            }

        }
    }

    public void pickingSecondStageMoves() {
        moveLibrary.creatingMoves();
        //TODO: NORMAL SECOND FORM


        if (normal.getVisibility() == View.INVISIBLE) {
            if (bossIndexNumber == 0) {
                displayBossInfo.setText(alteringStateBoss[0].toString() + bossMoveSet[0].toString());
            }
            if (bossIndexNumber == 1) {
                displayBossInfo.setText(alteringStateBoss[1].toString() + alteringBossMoveSet[1].toString());
                eyeOfCthulhu.setVisibility(View.INVISIBLE);
                eyeOfCthuluSS.setVisibility(View.VISIBLE);
            }
            if (bossIndexNumber == 2) {
                displayBossInfo.setText(alteringStateBoss[2].toString() + bossMoveSet[2].toString());
            }
            if (bossIndexNumber == 3) {
                displayBossInfo.setText(alteringStateBoss[3].toString() + bossMoveSet[3].toString());
                brainOfCthulhu.setVisibility(View.INVISIBLE);
                brainOfCthulhuSS.setVisibility(View.VISIBLE);
            }
            if (bossIndexNumber == 4) {
                displayBossInfo.setText(alteringStateBoss[4].toString() + bossMoveSet[4].toString());
            }
            if (bossIndexNumber == 5) {
                displayBossInfo.setText(alteringStateBoss[5].toString() + bossMoveSet[5].toString());
            }
            if (bossIndexNumber == 6) {
                displayBossInfo.setText(alteringStateBoss[6].toString() + bossMoveSet[6].toString());
            }
            if (bossIndexNumber == 7) {
                displayBossInfo.setText(alteringStateBoss[7].toString() + bossMoveSet[7].toString());
            }
            if (bossIndexNumber == 8) {
                displayBossInfo.setText(alteringStateBoss[8].toString() + bossMoveSet[8].toString());
                queenSlime.setVisibility(View.INVISIBLE);
                queenSlimeSS.setVisibility(View.VISIBLE);
            }
            if (bossIndexNumber == 9) {
                displayBossInfo.setText(alteringStateBoss[9].toString() + alteringBossMoveSet[9].toString());
                theTwins.setVisibility(View.INVISIBLE);
                theTwinsSS.setVisibility(View.VISIBLE);
            }
            if (bossIndexNumber == 10) {
                displayBossInfo.setText(alteringStateBoss[10].toString() + bossMoveSet[10].toString());
            }
            if (bossIndexNumber == 11) {
                displayBossInfo.setText(alteringStateBoss[11].toString() + bossMoveSet[11].toString());
            }
            if (bossIndexNumber == 12) {
                displayBossInfo.setText(alteringStateBoss[12].toString() + alteringBossMoveSet[12].toString());
                plantera.setVisibility(View.INVISIBLE);
                planteraSS.setVisibility(View.VISIBLE);
            }
            if (bossIndexNumber == 13) {
                displayBossInfo.setText(alteringStateBoss[13].toString() + alteringBossMoveSet[13].toString());
                golem.setVisibility(View.INVISIBLE);
                golemSS.setVisibility(View.VISIBLE);
            }
            if (bossIndexNumber == 14) {
                displayBossInfo.setText(alteringStateBoss[14].toString() + alteringBossMoveSet[14].toString());
                dukeFishron.setVisibility(View.INVISIBLE);
                dukeFishronSS.setVisibility(View.VISIBLE);
            }
            if (bossIndexNumber == 15) {
                displayBossInfo.setText(alteringStateBoss[15].toString() + alteringBossMoveSet[15].toString());
                empressOfLight.setVisibility(View.INVISIBLE);
                empressOfLightSS.setVisibility(View.VISIBLE);
            }
            if (bossIndexNumber == 16) {
                displayBossInfo.setText(alteringStateBoss[16].toString() + bossMoveSet[16].toString());
            }
            if (bossIndexNumber == 17) {
                displayBossInfo.setText(alteringStateBoss[17].toString() + bossMoveSet[17].toString());
            }
        }


        //TODO: EXPERT SECOND FORM


        if (expert.getVisibility() == View.INVISIBLE) {
            nextE.setVisibility(View.INVISIBLE);
            previousE.setVisibility(View.INVISIBLE);

            if (bossIndexNumber == 0) {
                displayBossInfo.setText(alteringExpertStateBoss[0].toString() + expertMoveSet[0].toString());
            }
            if (bossIndexNumber == 1) {
                displayBossInfo.setText(alteringExpertStateBoss[1].toString() + alteringExpertBossMoveSet[1].toString());
                eyeOfCthulhu.setVisibility(View.INVISIBLE);
                eyeOfCthuluSS.setVisibility(View.VISIBLE);
            }
            if (bossIndexNumber == 2) {
                displayBossInfo.setText(alteringExpertStateBoss[2].toString() + expertMoveSet[2].toString());
            }
            if (bossIndexNumber == 3) {
                displayBossInfo.setText(alteringExpertStateBoss[3].toString() + expertMoveSet[3].toString());
                brainOfCthulhu.setVisibility(View.INVISIBLE);
                brainOfCthulhuSS.setVisibility(View.VISIBLE);
            }
            if (bossIndexNumber == 4) {
                displayBossInfo.setText(alteringExpertStateBoss[4].toString() + expertMoveSet[4].toString());
            }
            if (bossIndexNumber == 5) {
                displayBossInfo.setText(alteringExpertStateBoss[5].toString() + expertMoveSet[5].toString());
            }
            if (bossIndexNumber == 6) {
                displayBossInfo.setText(alteringExpertStateBoss[6].toString() + expertMoveSet[6].toString());
            }
            if (bossIndexNumber == 7) {
                displayBossInfo.setText(alteringExpertStateBoss[7].toString() + expertMoveSet[7].toString());
            }
            if (bossIndexNumber == 8) {
                displayBossInfo.setText(alteringExpertStateBoss[8].toString() + expertMoveSet[8].toString());
                queenSlime.setVisibility(View.INVISIBLE);
                queenSlimeSS.setVisibility(View.VISIBLE);
            }
            if (bossIndexNumber == 9) {
                displayBossInfo.setText(alteringExpertStateBoss[9].toString() + alteringExpertBossMoveSet[9].toString());
                theTwins.setVisibility(View.INVISIBLE);
                theTwinsSS.setVisibility(View.VISIBLE);
            }
            if (bossIndexNumber == 10) {
                displayBossInfo.setText(alteringExpertStateBoss[10].toString() + expertMoveSet[10].toString());
            }
            if (bossIndexNumber == 11) {
                displayBossInfo.setText(alteringExpertStateBoss[11].toString() + expertMoveSet[11].toString());
            }
            if (bossIndexNumber == 12) {
                displayBossInfo.setText(alteringExpertStateBoss[12].toString() + alteringExpertBossMoveSet[12].toString());
                plantera.setVisibility(View.INVISIBLE);
                planteraSS.setVisibility(View.VISIBLE);
            }
            if (bossIndexNumber == 13) {
                displayBossInfo.setText(alteringExpertStateBoss[13].toString() + alteringExpertBossMoveSet[13].toString());
                golem.setVisibility(View.INVISIBLE);
                golemSS.setVisibility(View.VISIBLE);
            }
            if (bossIndexNumber == 14) {
                displayBossInfo.setText(alteringExpertStateBoss[14].toString() + alteringExpertBossMoveSet[14].toString());
                dukeFishron.setVisibility(View.INVISIBLE);
                dukeFishronSS.setVisibility(View.VISIBLE);
            }
            if (bossIndexNumber == 15) {
                displayBossInfo.setText(alteringExpertStateBoss[15].toString() + alteringExpertBossMoveSet[15].toString());
                empressOfLight.setVisibility(View.INVISIBLE);
                empressOfLightSS.setVisibility(View.VISIBLE);
            }
            if (bossIndexNumber == 16) {
                displayBossInfo.setText(alteringExpertStateBoss[16].toString() + expertMoveSet[16].toString());
            }
            if (bossIndexNumber == 17) {
                displayBossInfo.setText(alteringExpertStateBoss[17].toString() + expertMoveSet[17].toString());
            }
        }

        //TODO: MASTER SECOND FORM


        if (master.getVisibility() == View.INVISIBLE) {
            nextM.setVisibility(View.INVISIBLE);
            previousM.setVisibility(View.INVISIBLE);
            if (bossIndexNumber == 0) {
                displayBossInfo.setText(alteringMasterStateBoss[0].toString() + masterMoveSet[0].toString());
            }
            if (bossIndexNumber == 1) {
                displayBossInfo.setText(alteringMasterStateBoss[1].toString() + alteringMasterBossMoveSet[1].toString());
                eyeOfCthulhu.setVisibility(View.INVISIBLE);
                eyeOfCthuluSS.setVisibility(View.VISIBLE);
            }
            if (bossIndexNumber == 2) {
                displayBossInfo.setText(alteringMasterStateBoss[2].toString() + masterMoveSet[2].toString());
            }
            if (bossIndexNumber == 3) {
                displayBossInfo.setText(alteringMasterStateBoss[3].toString() + masterMoveSet[3].toString());
                brainOfCthulhu.setVisibility(View.INVISIBLE);
                brainOfCthulhuSS.setVisibility(View.VISIBLE);
            }
            if (bossIndexNumber == 4) {
                displayBossInfo.setText(alteringMasterStateBoss[4].toString() + masterMoveSet[4].toString());
            }
            if (bossIndexNumber == 5) {
                displayBossInfo.setText(alteringMasterStateBoss[5].toString() + masterMoveSet[5].toString());
            }
            if (bossIndexNumber == 6) {
                displayBossInfo.setText(alteringMasterStateBoss[6].toString() + masterMoveSet[6].toString());
            }
            if (bossIndexNumber == 7) {
                displayBossInfo.setText(alteringMasterStateBoss[7].toString() + masterMoveSet[7].toString());
            }
            if (bossIndexNumber == 8) {
                displayBossInfo.setText(alteringMasterStateBoss[8].toString() + masterMoveSet[8].toString());
                queenSlime.setVisibility(View.INVISIBLE);
                queenSlimeSS.setVisibility(View.VISIBLE);
            }
            if (bossIndexNumber == 9) {
                displayBossInfo.setText(alteringMasterStateBoss[9].toString() + alteringMasterBossMoveSet[9].toString());
                theTwins.setVisibility(View.INVISIBLE);
                theTwinsSS.setVisibility(View.VISIBLE);
            }
            if (bossIndexNumber == 10) {
                displayBossInfo.setText(alteringMasterStateBoss[10].toString() + masterMoveSet[10].toString());
            }
            if (bossIndexNumber == 11) {
                displayBossInfo.setText(alteringMasterStateBoss[11].toString() + masterMoveSet[11].toString());
            }
            if (bossIndexNumber == 12) {
                displayBossInfo.setText(alteringMasterStateBoss[12].toString() + alteringMasterBossMoveSet[12].toString());
                plantera.setVisibility(View.INVISIBLE);
                planteraSS.setVisibility(View.VISIBLE);
            }
            if (bossIndexNumber == 13) {
                displayBossInfo.setText(alteringMasterStateBoss[13].toString() + alteringMasterBossMoveSet[13].toString());
                golem.setVisibility(View.INVISIBLE);
                golemSS.setVisibility(View.VISIBLE);
            }
            if (bossIndexNumber == 14) {
                displayBossInfo.setText(alteringMasterStateBoss[14].toString() + alteringMasterBossMoveSet[14].toString());
                dukeFishron.setVisibility(View.INVISIBLE);
                dukeFishronSS.setVisibility(View.VISIBLE);
            }
            if (bossIndexNumber == 15) {
                displayBossInfo.setText(alteringMasterStateBoss[15].toString() + alteringMasterBossMoveSet[15].toString());
                empressOfLight.setVisibility(View.INVISIBLE);
                empressOfLightSS.setVisibility(View.VISIBLE);
            }
            if (bossIndexNumber == 16) {
                displayBossInfo.setText(alteringMasterStateBoss[16].toString() + masterMoveSet[16].toString());
            }
            if (bossIndexNumber == 17) {
                displayBossInfo.setText(alteringMasterStateBoss[17].toString() + masterMoveSet[17].toString());
            }
        }
    }
}