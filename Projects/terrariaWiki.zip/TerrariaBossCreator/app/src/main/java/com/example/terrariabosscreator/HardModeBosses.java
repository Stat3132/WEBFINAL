package com.example.terrariabosscreator;

public enum HardModeBosses {
    QUEEN_SLIME("Queen slime"),
    THE_TWINS("The twins (Retinazar and Spazmatism)"),
    THE_DESTORYER("The destroyer"),
    SKELETRON_PRIME("Skeletron prime"),
    PLANTERA("Plantera"),
    GOLEM("Golem"),
    DUKE_FISHERON("Duke fisheron"),
    EMPRESS_OF_LIGHT("Empress of light"),
    LUNATIC_CULTIST("Lunatic cultist"),
    MOON_LORD("Moon lord");





    private String friendlyHardBosses;


    HardModeBosses(String friendlyHardBosses){
        this.friendlyHardBosses = friendlyHardBosses;
    }

    @Override
    public String toString() {
        return this.friendlyHardBosses;
    }
}
